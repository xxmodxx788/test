# Meteorology AI — Local Partner Hardened

Two local models only: GPT-OSS 20B primary and Qwen3-VL 4B vision specialist.

GPT-OSS remains persistent on port 8080. Qwen is a secondary local vision server on port 8081.

Research modes: Normal, Web Research, Deep Research, Trusted Government.

Thinking controls: Auto, Low, Medium, High.

Logs are created in the application `logs/` directory.

Conversation deletion is available with right-click in the conversation list.

The app uses bounded context, preserves complete tool-call message groups, disables parallel tool calls at the model API boundary for reliability, and uses the application as the authoritative image/evidence broker.

## Backend stack

Scientific stack: NumPy, SciPy, MetPy, Pint, Numba, xarray, cfgrib, ecCodes, Dask, Zarr. Fast structured data: orjson, msgspec, PyArrow. Image stack: Pillow, ImageIO, headless OpenCV. GUI/performance: PySide6, PyQtGraph. System telemetry: psutil. Async support: qasync.

OpenCV is the headless wheel to avoid introducing a second Qt GUI stack; ImageIO complements Pillow for broader image/sequence decoding.

Backend behavior: orjson/msgspec are used for model/tool JSON boundaries; ImageIO + headless OpenCV + Pillow form the image normalization path; MetPy/Pint validate meteorological units; PyArrow stores completed performance history; Dask/Zarr/Numba are available behind isolated adapters for larger scientific workloads.

## Observability

The application now uses a correlated, fault-tolerant telemetry layer. Each workflow receives a trace ID; events carry event/sequence IDs, timestamps, component/stage/outcome, and optional parent/span IDs. The authoritative stream is `logs/events.jsonl`, while `logs/workflow.jsonl` and `logs/performance.jsonl` remain compatible projections.

Per-request diagnostics are stored under `logs/traces/<trace_id>/`, including a timeline and model/tool artifacts. Tool calls preserve arguments/results in trace-local artifacts, NWP calls record requested/returned/parsed field inventories, model responses preserve server-reported usage/timings when available, and image processing records dimensions/hashes/transforms.

Logging is asynchronous and bounded so normal GUI/model work is not blocked by routine event writes. Critical errors are mirrored to `events_emergency.jsonl`. Secrets are redacted before structured telemetry is persisted. Logging failures are intentionally non-fatal.
