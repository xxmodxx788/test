import sys,faulthandler
from PySide6.QtWidgets import QApplication
from meteorology_ai.config import init_dirs
from meteorology_ai.logging_utils import install_excepthook
from meteorology_ai.ui import Main
from meteorology_ai.logging_utils import workflow
from meteorology_ai.backend import backend_versions
init_dirs(); workflow('backend','versions',detail=str(backend_versions())); faulthandler.enable(open((__import__('pathlib').Path(__file__).resolve().parent/'logs'/'fault.log'),'a',encoding='utf-8'));install_excepthook();app=QApplication(sys.argv);w=Main();w.show();sys.exit(app.exec())
