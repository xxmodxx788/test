from __future__ import annotations
import json,re,shutil
from .backend import json_dumps
from datetime import datetime
from pathlib import Path
from .config import CONV_DIR,WS_DIR,LIB_DIR,GEN_DIR

def safe(s): return re.sub(r'[<>:"/\\|?*]','_',str(s).strip() or 'Untitled')[:100]
def atomic_json(path,data):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json_dumps(data,pretty=True),encoding='utf-8'); tmp.replace(path)
def load_json(path,default=None):
    try:return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:return default

def save_conv(conv,ws=None):
    base=(WS_DIR/ws/'conversations') if ws else CONV_DIR; base.mkdir(parents=True,exist_ok=True)
    conv=conv.copy(); conv['id']=conv.get('id') or datetime.now().strftime('%Y%m%d_%H%M%S_%f'); conv['updated']=datetime.now().isoformat()
    path=base/f"{conv['id']}_{safe(conv.get('title','Conversation'))}.json"; atomic_json(path,conv); return path

def list_conv(ws=None):
    base=(WS_DIR/ws/'conversations') if ws else CONV_DIR; base.mkdir(parents=True,exist_ok=True); out=[]
    for p in base.glob('*.json'):
        d=load_json(p)
        if d: d['_path']=str(p); out.append(d)
    return sorted(out,key=lambda x:x.get('updated',''),reverse=True)

def delete_conv(path):
    p=Path(path)
    if p.is_file() and p.suffix.lower()=='.json': p.unlink()

def save_ws(d):
    d=d.copy(); d.setdefault('id',datetime.now().strftime('ws_%Y%m%d_%H%M%S_%f')); d['updated']=datetime.now().isoformat(); p=WS_DIR/d['id']; p.mkdir(parents=True,exist_ok=True); (p/'conversations').mkdir(exist_ok=True); atomic_json(p/'workspace.json',d); return p

def list_ws():
    out=[]
    for p in WS_DIR.glob('*/workspace.json'):
        d=load_json(p)
        if d: out.append(d)
    return sorted(out,key=lambda x:x.get('updated',''),reverse=True)

def mem(ws): return load_json(WS_DIR/ws/'memory.json',{'notes':'','facts':[]}) or {'notes':'','facts':[]}
def save_mem(ws,d): atomic_json(WS_DIR/ws/'memory.json',d)

def save_attachment(src, kind='image'):
    src=Path(src); GEN_DIR.mkdir(parents=True,exist_ok=True); out=GEN_DIR/f"{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_{safe(src.stem)}{src.suffix.lower()}"; shutil.copy2(src,out); return str(out)
