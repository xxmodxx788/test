from __future__ import annotations
import os,time,subprocess,re,threading
from pathlib import Path
try:import psutil
except Exception:psutil=None
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QMainWindow,QWidget,QVBoxLayout,QLabel,QPlainTextEdit,QTableWidget,QTableWidgetItem
pg=None
from .config import LOG_DIR
from .telemetry import TELEMETRY
from .runtime import MODELS


_LLAMA_CACHE = {}

def _llama_stats(port):
    p=LOG_DIR/f'local_server_{port}.log'
    try:
        sig=(p.stat().st_mtime_ns,p.stat().st_size) if p.exists() else (0,0)
        cached=_LLAMA_CACHE.get(port)
        if cached and cached[0]==sig:
            return dict(cached[1])
        base=f'http://127.0.0.1:{port}'
        metrics_result={}
        try:
            import requests
            r=requests.get(base+'/metrics',timeout=0.6)
            if r.ok:
                for line in (r.text or '').splitlines():
                    if not line or line.startswith('#') or ' ' not in line:continue
                    k,v=line.rsplit(' ',1)
                    try:metrics_result[k]=float(v)
                    except ValueError:continue
        except Exception:
            pass
        if metrics_result:
            result={'alive':True,
                    'prompt_tokens_total':metrics_result.get('llamacpp:prompt_tokens_total'),
                    'predicted_tokens_total':metrics_result.get('llamacpp:tokens_predicted_total'),
                    'prompt_tps':metrics_result.get('llamacpp:prompt_tokens_seconds'),
                    'gen_tps':metrics_result.get('llamacpp:predicted_tokens_seconds'),
                    'kv_cache_usage_ratio':metrics_result.get('llamacpp:kv_cache_usage_ratio'),
                    'kv_cache_tokens':metrics_result.get('llamacpp:kv_cache_tokens'),
                    'requests_processing':metrics_result.get('llamacpp:requests_processing'),
                    'requests_deferred':metrics_result.get('llamacpp:requests_deferred'),
                    'n_tokens_max':metrics_result.get('llamacpp:n_tokens_max'),
                    'source':'metrics'}
            _LLAMA_CACHE[port]=(sig,result);return dict(result)
        text=p.read_text(encoding='utf-8',errors='replace')[-12000:] if p.exists() else ''
        start=text.rfind('===== server start ====='); current=text[start:] if start>=0 else text
        gen=re.findall(r'n_gen\s*=\s*\d+, tg\s*=\s*([0-9.]+) t/s',current)
        pe=re.findall(r'prompt eval time =\s*([0-9.]+) ms /\s*([0-9]+) tokens',current)
        ev=re.findall(r'eval time =\s*([0-9.]+) ms /\s*([0-9]+) tokens',current)
        result={'alive':'listening on http://127.0.0.1' in current,'gen_tps':float(gen[-1]) if gen else None,'prompt_tps':(float(pe[-1][1])/(float(pe[-1][0])/1000.0)) if pe else None,'eval_ms':float(ev[-1][0]) if ev else None,'generated_tokens':int(ev[-1][1]) if ev else None,'source':'server_log'}
        _LLAMA_CACHE[port]=(sig,result);return dict(result)
    except Exception:return {'alive':False,'source':'unavailable'}

class PerfSampler:
    def __init__(self):self.lock=threading.RLock();self.latest={};self.running=False;self.thread=None
    def start(self):
        if self.running:return
        self.running=True;self.thread=threading.Thread(target=self._loop,name='PerfSampler',daemon=True);self.thread.start()
    def stop(self):self.running=False
    def _loop(self):
        proc=psutil.Process(os.getpid()) if psutil else None
        if proc:
            try:proc.cpu_percent(None)
            except Exception:pass
        while self.running:
            snap={}
            try:
                if psutil:
                    vm=psutil.virtual_memory();snap.update(cpu_percent=psutil.cpu_percent(interval=None),ram_used=vm.used,ram_total=vm.total,process_ram=proc.memory_info().rss,process_cpu=proc.cpu_percent(interval=None))
                for role,port in [('GPT-OSS',8080),('Qwen3-VL',8081)]:snap[role.replace('-','_').lower()+'_stats']=_llama_stats(port);snap[role.replace('-','_').lower()+'_server']=bool(MODELS.primary and MODELS.primary.alive) if port==8080 else bool(MODELS.vision and MODELS.vision.alive)
            except Exception as e:snap['error']=str(e)
            with self.lock:self.latest=snap
            time.sleep(1)
    def snapshot(self):
        with self.lock:return dict(self.latest)

PERF=PerfSampler()

class LivePerformance(QMainWindow):
    def __init__(self,parent=None):
        super().__init__(parent);self.setWindowTitle('Live Performance');self.resize(780,650);root=QWidget();lay=QVBoxLayout(root);self.labels={}; self.history=[]
        for key in ('CPU','RAM','App RAM','App CPU','GPT-OSS Server','Qwen3-VL Server','Workflow','Elapsed','Warnings','Errors'):
            lab=QLabel(key);self.labels[key]=lab;lay.addWidget(lab)
        self.plot=None
        global pg
        if pg is None:
            try:
                import pyqtgraph as _pg
                pg = _pg
            except Exception:
                pg = None
        if pg is not None:
            self.plot=pg.PlotWidget(title='System CPU / App CPU'); self.plot.setLabel('left','Percent'); self.plot.setLabel('bottom','Samples'); self.plot.showGrid(x=True,y=True,alpha=0.2); self.cpu_curve=self.plot.plot(); self.app_curve=self.plot.plot(); lay.addWidget(self.plot)
        self.events=QPlainTextEdit();self.events.setReadOnly(True);lay.addWidget(self.events,1);self.setCentralWidget(root);self.timer=QTimer(self);self.timer.timeout.connect(self.refresh);self.timer.start(750);self.refresh()
    def refresh(self):
        try:
            s=PERF.snapshot();t=TELEMETRY.snapshot();self.labels['CPU'].setText(f"CPU: {s.get('cpu_percent','—')} %");self.labels['RAM'].setText(f"RAM: {((s.get('ram_used') or 0)/1e9):.1f} / {((s.get('ram_total') or 0)/1e9):.1f} GB");self.labels['App RAM'].setText(f"App RAM: {((s.get('process_ram') or 0)/1e6):.1f} MB");self.labels['App CPU'].setText(f"App CPU: {s.get('process_cpu','—')} %")
            ps=s.get('gpt_oss_stats',{});qs=s.get('qwen3_vl_stats',{});self.labels['GPT-OSS Server'].setText(f"GPT-OSS: {'ACTIVE' if s.get('gpt_oss_server') else 'idle'} • gen {ps.get('gen_tps') or '—'} tok/s • prompt {ps.get('prompt_tps') or '—'} tok/s");self.labels['Qwen3-VL Server'].setText(f"Qwen3-VL: {'ACTIVE' if s.get('qwen3_vl_server') else 'idle'} • gen {qs.get('gen_tps') or '—'} tok/s • prompt {qs.get('prompt_tps') or '—'} tok/s")
            self.history.append((float(s.get('cpu_percent') or 0),float(s.get('process_cpu') or 0))); self.history=self.history[-120:];
            if self.plot is not None:
                self.cpu_curve.setData([x[0] for x in self.history]); self.app_curve.setData([x[1] for x in self.history])
            self.labels['Workflow'].setText(f"Workflow: {t['stage']} ({t['percent']}%)");self.labels['Elapsed'].setText(f"Elapsed: {t['elapsed_s']:.1f}s");self.labels['Warnings'].setText(f"Warnings: {t['warnings']}");self.labels['Errors'].setText(f"Errors: {t['errors']}");self.events.setPlainText('\n'.join(f"{e['time']} | {e['stage']} | {e['percent']}% | {e['state']} | {e['detail']}" for e in t['events']))
        except RuntimeError:pass
    def closeEvent(self,e):self.hide();e.ignore()

class Diagnostics(QMainWindow):
    def __init__(self,parent=None):
        super().__init__(parent);self.setWindowTitle('Performance Diagnostics');self.resize(1000,560);root=QWidget();lay=QVBoxLayout(root);self.table=QTableWidget(0,7);self.table.setHorizontalHeaderLabels(['Completed','Duration','Model','Tool events','Warnings','Errors','Bottleneck']);lay.addWidget(self.table);self.setCentralWidget(root);self.timer=QTimer(self);self.timer.timeout.connect(self.refresh);self.timer.start(1200);self.refresh()
    def refresh(self):
        try:
            rows=TELEMETRY.summaries_snapshot();self.table.setRowCount(len(rows))
            for r,row in enumerate(rows):
                vals=(row.get('completed',''),row.get('duration_s',''),row.get('model','GPT-OSS'),row.get('tool_count',''),row.get('warnings',''),row.get('errors',''),row.get('bottleneck',''))
                for c,v in enumerate(vals):self.table.setItem(r,c,QTableWidgetItem(str(v)))
        except RuntimeError:pass
    def closeEvent(self,e):self.hide();e.ignore()
