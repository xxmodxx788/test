from __future__ import annotations
"""Shared scientific/serialization/image backend.

All optional heavy libraries are centralized here so the rest of the app has a
small, stable interface and can be tested without importing GUI/image stacks.
"""
import base64
import json
from pathlib import Path
from typing import Any

import numpy as np

try:
    import orjson
except Exception:
    orjson = None

try:
    import msgspec
except Exception:
    msgspec = None

try:
    import cv2
except Exception:
    cv2 = None

try:
    import imageio.v3 as imageio
except Exception:
    imageio = None

try:
    from PIL import Image
except Exception:
    Image = None

# Heavy scientific/image modules are intentionally imported only inside the feature that needs them.
# This keeps normal GUI startup fast even though the full scientific/image stack is installed.
scipy = pint = metpy = dask = zarr = pyarrow = numba = cv2 = imageio = Image = None


def json_dumps(value: Any, *, pretty: bool = False) -> str:
    """Serialize JSON using orjson when available, with stdlib fallback."""
    if orjson is not None:
        option = orjson.OPT_NON_STR_KEYS
        if pretty:
            option |= orjson.OPT_INDENT_2
        return orjson.dumps(value, option=option, default=_default).decode("utf-8")
    return json.dumps(value, ensure_ascii=False, allow_nan=False, default=_default, indent=2 if pretty else None, separators=None if pretty else (",", ":"))


def json_loads(value: str | bytes) -> Any:
    if orjson is not None:
        return orjson.loads(value)
    return json.loads(value)


def validate_json_object(raw: str | bytes) -> dict[str, Any]:
    """Strictly decode a JSON object for model/tool arguments."""
    if msgspec is not None:
        obj = msgspec.json.decode(raw)
    else:
        obj = json_loads(raw)
    if not isinstance(obj, dict):
        raise ValueError("JSON payload must be an object")
    return obj


def _default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if hasattr(value, "isoformat"):
        return value.isoformat()
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def image_to_png(source: str | Path, target: str | Path, max_side: int = 1800) -> dict[str, Any]:
    """Decode a weather image robustly and write a Qwen-friendly PNG.

    ImageIO is preferred for broad format/sequence handling; OpenCV handles
    efficient resize/color conversion; Pillow remains the compatibility
    fallback for formats ImageIO/OpenCV cannot decode.
    """
    source = Path(source)
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    arr = None
    source_format = source.suffix.lower().lstrip(".")

    try:
        import imageio.v3 as _imageio
    except Exception:
        _imageio = None
    try:
        from PIL import Image as _Image
    except Exception:
        _Image = None
    try:
        import cv2 as _cv2
    except Exception:
        _cv2 = None

    if _imageio is not None:
        try:
            read_kwargs = {'index': 0} if source.suffix.lower() in {'.gif', '.tif', '.tiff', '.webp'} else {}
            arr = _imageio.imread(source, **read_kwargs)
            source_format = source.suffix.lower().lstrip('.')
        except Exception:
            arr = None

    if arr is None and _Image is not None:
        try:
            with _Image.open(source) as im:
                im.seek(0)
                arr = np.asarray(im.convert("RGBA" if "A" in im.getbands() else "RGB"))
                source_format = (im.format or source.suffix.lstrip(".")).lower()
        except Exception:
            arr = None

    if arr is None:
        raise ValueError(f"Unable to decode image: {source}")

    arr = np.asarray(arr)
    if arr.ndim == 2:
        arr = np.repeat(arr[..., None], 3, axis=2)
    if arr.shape[-1] == 4:
        arr = arr[..., :4]

    if _cv2 is not None:
        height, width = arr.shape[:2]
        scale = min(1.0, max_side / max(height, width))
        if scale < 1.0:
            arr = _cv2.resize(arr, (max(1, round(width * scale)), max(1, round(height * scale))), interpolation=cv2.INTER_AREA)
        # OpenCV expects BGR/BGRA for PNG encoding.
        encode_arr = arr[..., ::-1] if arr.shape[-1] in (3, 4) else arr
        ok, encoded = _cv2.imencode(".png", encode_arr, [_cv2.IMWRITE_PNG_COMPRESSION, 3])
        if not ok:
            raise ValueError("OpenCV could not encode PNG")
        target.write_bytes(encoded.tobytes())
    elif _Image is not None:
        im = _Image.fromarray(arr)
        im.thumbnail((max_side, max_side), _Image.Resampling.LANCZOS)
        im.save(target, "PNG", optimize=True)
    else:
        raise RuntimeError("No image encoder available")

    return {"source_format": source_format, "format": "png", "width": int(arr.shape[1]), "height": int(arr.shape[0]), "bytes": target.stat().st_size}


def image_data_uri(path: str | Path) -> str:
    path = Path(path)
    raw = path.read_bytes()
    return "data:image/png;base64," + base64.b64encode(raw).decode("ascii")


def quantity(value: float, unit: str):
    """Return a Pint quantity, preferring MetPy's unit registry when present."""
    try:
        import metpy
    except Exception:
        metpy = None
    try:
        import pint
    except Exception:
        pint = None
    if metpy is not None:
        try:
            from metpy.units import units as metpy_units
            return float(value) * metpy_units(unit)
        except Exception:
            pass
    if pint is not None:
        return float(value) * pint.UnitRegistry()(unit)
    return (float(value), unit)


def compatible_unit(value: float, source_unit: str, target_unit: str) -> float:
    q = quantity(value, source_unit)
    if hasattr(q, "to"):
        return float(q.to(target_unit).magnitude)
    if source_unit == target_unit:
        return float(value)
    # Small dependency-free fallback for common meteorological distance/energy units.
    key=(source_unit.strip().lower().replace(' ',''), target_unit.strip().lower().replace(' ',''))
    factors={('m','km'):1e-3,('km','m'):1e3,('pa','hpa'):1e-2,('hpa','pa'):1e2,('kt','m/s'):0.5144444444444445,('m/s','kt'):1.9438444924406048,('j/kg','jkg'):1.0}
    if key in factors:
        return float(value)*factors[key]
    raise ValueError(f"Unit conversion unavailable: {source_unit} -> {target_unit}")


def append_parquet_row(path: str | Path, row: dict[str, Any]) -> None:
    """Append a small structured history row using PyArrow when available.

    Failures are intentionally non-fatal because JSONL remains the authoritative log.
    """
    try:
        import pyarrow
    except Exception:
        pyarrow = None
    if pyarrow is None:
        return
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        table = pa.Table.from_pylist([row])
        if path.exists():
            old = pq.read_table(path)
            table = pa.concat_tables([old, table], promote_options='default')
        pq.write_table(table, path, compression='zstd')
    except Exception:
        return


def backend_versions() -> dict[str, str | None]:
    # Read installed distribution metadata without importing heavy modules.
    from importlib.metadata import version as dist_version, PackageNotFoundError
    def v(name):
        try: return dist_version(name)
        except PackageNotFoundError: return None
        except Exception: return None
    return {
        'numpy': v('numpy'), 'orjson': v('orjson'), 'msgspec': v('msgspec'),
        'opencv': v('opencv-python-headless') or v('opencv-python'), 'imageio': v('imageio'),
        'scipy': v('scipy'), 'pint': v('pint'), 'metpy': v('metpy'), 'dask': v('dask'),
        'zarr': v('zarr'), 'pyarrow': v('pyarrow'), 'numba': v('numba'),
        'pyqtgraph': v('pyqtgraph'), 'qasync': v('qasync')
    }
