from __future__ import annotations
import base64
import json
import contextvars
import mimetypes
import os
import time
import hashlib
from copy import deepcopy
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import requests
from PIL import Image
from .backend import json_dumps, validate_json_object, image_to_png, image_data_uri, backend_versions
from .config import GEN_DIR, resolve_model_path
from .weather_tools import *
from .runtime import MODELS
from .telemetry import TELEMETRY
from .logging_utils import workflow, performance, write_prompt_audit, write_model_trace, write_tool_trace, start_trace, finish_trace, reset_trace_context, span, event
from .collaboration import inspect_application

class WorkflowCancelled(RuntimeError):
    pass

TOOLS=[web_search,nws_point_weather,nws_alerts,nws_observations,ncei_search,ncei_data,spc_outlook,nexrad_radar,goes19,nwp_model_guidance,meteorological_analysis_bundle,fetch_url,inspect_application]
TOOLMAP={x.__name__:x for x in TOOLS}
SCHEMAS={
'web_search':{'type':'object','properties':{'query':{'type':'string'},'max_results':{'type':'integer'}},'required':['query']},
'nws_point_weather':{'type':'object','properties':{'latitude':{'type':'number'},'longitude':{'type':'number'}},'required':['latitude','longitude']},
'nws_alerts':{'type':'object','properties':{'latitude':{'type':'number'},'longitude':{'type':'number'},'area':{'type':'string'}},'required':[]},
'nws_observations':{'type':'object','properties':{'latitude':{'type':'number'},'longitude':{'type':'number'}},'required':['latitude','longitude']},
'ncei_search':{'type':'object','properties':{'keyword':{'type':'string'}},'required':['keyword']},
'ncei_data':{'type':'object','properties':{'dataset':{'type':'string'},'start_date':{'type':'string'},'end_date':{'type':'string'},'stations':{'type':'string'},'datatype':{'type':'string'},'units':{'type':'string'},'limit':{'type':'integer'}},'required':['dataset','start_date','end_date']},
'spc_outlook':{'type':'object','properties':{},'required':[]},
'nexrad_radar':{'type':'object','properties':{'radar_site':{'type':'string'},'product_index':{'type':'integer'}},'required':['radar_site']},
'goes19':{'type':'object','properties':{},'required':[]},
'nwp_model_guidance':{'type':'object','properties':{'model':{'type':'string','enum':['hrrr','gfs']},'latitude':{'type':'number'},'longitude':{'type':'number'},'forecast_hour':{'type':'integer'},'include_upper_air':{'type':'boolean'}},'required':['model','latitude','longitude']},
'meteorological_analysis_bundle':{'type':'object','properties':{'latitude':{'type':'number'},'longitude':{'type':'number'},'forecast_hour':{'type':'integer'}},'required':['latitude','longitude']},
'fetch_url':{'type':'object','properties':{'url':{'type':'string'}},'required':['url']},
'inspect_application':{'type':'object','properties':{'files':{'type':'array','items':{'type':'string'}},'max_chars_per_file':{'type':'integer'},'max_total_chars':{'type':'integer'}},'required':[]}}
TOOL_SPECS=[{'type':'function','function':{'name':f.__name__,'description':f.__doc__ or f.__name__,'parameters':SCHEMAS.get(f.__name__,{'type':'object','properties':{},'required':[]})}} for f in TOOLS]
VISION_SCHEMAS={
'vision_analyze':{'type':'object','properties':{'image_url':{'type':'string'},'prompt':{'type':'string'},'attachment_ids':{'type':'array','items':{'type':'string'}}},'required':['prompt']},
'vision_compare':{'type':'object','properties':{'image_urls':{'type':'array','items':{'type':'string'}},'attachment_ids':{'type':'array','items':{'type':'string'}},'prompt':{'type':'string'}},'required':['prompt']},
'vision_partner_consult':{'type':'object','properties':{'prompt':{'type':'string'}},'required':['prompt']}}
VISION_SPECS=[{'type':'function','function':{'name':n,'description':d,'parameters':VISION_SCHEMAS[n]}} for n,d in [('vision_analyze','Send one or more image inputs to the local Qwen3-VL vision specialist for pixel-level visual analysis.'),('vision_compare','Send multiple image inputs to Qwen3-VL for side-by-side comparison.'),('vision_partner_consult','Ask Qwen3-VL for advice about the two-model partnership or multimodal application design. No image is required.')]]


def system_prompt(cfg,ws=None,mem=None):
    parts=[cfg.get('system_prompt',''),f"CURRENT RESEARCH MODE: {cfg.get('research_mode','normal')}."]
    if cfg.get('research_mode')=='trusted': parts.append('Use direct NOAA/NWS/NCEI/NESDIS/SPC/NCEP/NOMADS sources exposed by the application when possible.')
    elif cfg.get('research_mode')=='web': parts.append('Use external web/data tools exposed by the application when current information is required. Prefer authoritative sources.')
    elif cfg.get('research_mode')=='deep': parts.append('Perform a bounded multi-source investigation. Use parallel independent data retrieval only when it is genuinely independent. Stop once sufficient evidence is gathered.')
    if cfg.get('global_instructions'): parts.append('GLOBAL INSTRUCTIONS:\n'+str(cfg['global_instructions'])[:12000])
    if cfg.get('advanced_system_instructions'): parts.append('ADVANCED INSTRUCTIONS:\n'+str(cfg['advanced_system_instructions'])[:12000])
    if ws and ws.get('instructions'): parts.append('WORKSPACE INSTRUCTIONS:\n'+str(ws['instructions'])[:8000])
    if mem:
        if mem.get('notes'): parts.append('WORKSPACE MEMORY:\n'+str(mem['notes'])[:6000])
        facts=mem.get('facts') or []
        if facts: parts.append('WORKSPACE FACTS:\n'+'\n'.join(map(str,facts[:80]))[:6000])
    return '\n\n'.join(x for x in parts if x)


def _json_size(x):
    try:return len(json_dumps(x))
    except Exception:return 0


def _normalize_assistant_message(msg):
    """Prepare llama.cpp gpt-oss assistant messages for safe multi-turn replay."""
    out=deepcopy(msg or {})
    calls=out.get('tool_calls') or []
    # llama.cpp GPT-OSS templates can reject an assistant tool-call message that has both
    # content and thinking/reasoning_content. Preserve the reasoning internally but send the
    # template-safe representation back to the server.
    if calls:
        if out.get('reasoning_content'):
            out['thinking']=out.get('reasoning_content')
        out.pop('reasoning_content',None)
        out.pop('content',None)
    # Never replay opaque provider-specific fields that can upset the local template.
    allowed={'role','content','tool_calls','thinking','name','tool_call_id'}
    return {k:v for k,v in out.items() if k in allowed}


def _tool_grouped_messages(messages):
    """Yield system + coherent conversation groups so compaction never splits tool calls from results."""
    if not messages:return []
    groups=[messages[0]] if messages[0].get('role')=='system' else []
    buf=[]
    for m in messages[1:] if messages and messages[0].get('role')=='system' else messages:
        role=m.get('role')
        if role=='user' and buf:
            groups.append(buf);buf=[m]
        else: buf.append(m)
    if buf:groups.append(buf)
    return groups


def compact_messages(messages,max_chars=48000,max_groups=8):
    groups=_tool_grouped_messages(messages)
    if not groups:return []
    system=groups[0] if isinstance(groups[0],dict) else None
    convo=groups[1:] if system else groups
    chosen=convo[-max_groups:]
    out=[]
    if system:out.append(system)
    out.extend(chosen)
    # Trim oldest coherent groups first. Never split assistant tool call/result bundles.
    def total():return sum(_json_size(x) for x in out)
    while total()>max_chars and len(out)>2:
        del out[1]
    # Per-message caps for tool output; preserve valid JSON envelope instead of cutting JSON raw text.
    for item in out:
        if isinstance(item,list):
            for m in item:
                if m.get('role')=='tool' and isinstance(m.get('content'),str) and len(m['content'])>7000:
                    try:
                        obj=json.loads(m['content'])
                        m['content']=json.dumps({'truncated':True,'original_keys':list(obj.keys())[:40],'summary':str(obj)[:6800]},ensure_ascii=False)
                    except Exception:
                        m['content']=m['content'][:7000]+'\n[tool output truncated]'
    flat=[]
    for item in out:
        if isinstance(item,dict):flat.append(item)
        else:flat.extend(item)
    return flat


def _parse_args(raw,name):
    try:
        obj=validate_json_object(raw or '{}')
        if not isinstance(obj,dict): raise ValueError('tool arguments must be a JSON object')
        return obj,None
    except Exception as e:
        workflow('tool_args','json_parse','warning',str(e),tool=name,payload_preview=(raw or '')[:800])
        return {},f'Invalid tool arguments for {name}: {e}'


def _safe_tool_result(obj,max_chars=12000):
    """Return valid JSON text while bounding tool-result size without truncating JSON syntax."""
    try:
        s=json_dumps(obj)
        if len(s)<=max_chars:return s
        # Preserve structure for dict results; only truncate individual large textual values.
        if isinstance(obj,dict):
            out={}
            budget=max_chars-200
            for k,v in obj.items():
                if budget<=0:break
                if isinstance(v,str):
                    vv=v[:min(len(v),max(200, budget//4))]
                elif isinstance(v,list) and len(v)>40:
                    vv=v[:40]
                else:vv=v
                out[k]=vv
                budget-=min(_json_size(vv)+8,budget)
            out['_truncated']=True
            packed=json_dumps(out)
            if len(packed)<=max_chars:return packed
            return json_dumps({'_truncated':True,'summary':str(obj)[:max_chars-80]})
        return json_dumps({'truncated':True,'preview':str(obj)[:max_chars-100]})
    except Exception as e:
        return json_dumps({'error':'tool result serialization failed','detail':str(e)})


def _download_image(url):
    key=hashlib.sha1(url.encode('utf-8')).hexdigest()[:12]
    cached=list(GEN_DIR.glob(f'radar_{key}.*'))
    if cached:
        raw=next((p for p in cached if p.suffix.lower() in ('.gif','.png','.jpg','.jpeg','.webp','.bmp','.tif','.tiff')),cached[0])
        vision=raw.with_suffix('.png') if raw.with_suffix('.png').exists() else raw
        try:
            with Image.open(raw) as im:
                event('image.cache_hit', component='image', stage='cache', outcome='SUCCESS', image_id=key, source_url=url,
                      raw_path=str(raw), raw_bytes=raw.stat().st_size, width=im.width, height=im.height, format=im.format)
        except Exception:
            event('image.cache_hit', component='image', stage='cache', outcome='PARTIAL', image_id=key, source_url=url, raw_path=str(raw), raw_bytes=raw.stat().st_size)
        return str(raw),str(vision),'',raw.stat().st_size
    t0=time.monotonic()
    try:
        r=requests.get(url,headers={'Accept':'image/*','User-Agent':'MeteorologyAI/1.0'},timeout=(5,15));r.raise_for_status()
        ctype=r.headers.get('content-type','').split(';')[0]
        ext='.gif' if 'gif' in ctype or url.lower().endswith('.gif') else (Path(url.split('?',1)[0]).suffix.lower() or '.png')
        raw=GEN_DIR/f'radar_{key}{ext}';raw.write_bytes(r.content)
        event('image.download', component='image', stage='download', outcome='SUCCESS', image_id=key, source_url=url,
              http_status=r.status_code, response_bytes=len(r.content), content_type=ctype, duration_ms=round((time.monotonic()-t0)*1000,3))
    except Exception as e:
        event('image.download', component='image', stage='download', severity='ERROR', state='error', outcome='FAILED', image_id=key, source_url=url,
              error_type=type(e).__name__, error_message=str(e), duration_ms=round((time.monotonic()-t0)*1000,3))
        raise
    vision=raw
    try:
        if raw.suffix.lower() != '.png':
            vision=raw.with_suffix('.png')
            image_to_png(raw, vision, max_side=1800)
        else:
            # Normalize oversized PNGs as well.
            try:
                from PIL import Image as _Image
                with _Image.open(raw) as im:
                    if max(im.size)>1800:
                        vision=raw.with_suffix('.vision.png')
                        image_to_png(raw, vision, max_side=1800)
            except Exception: pass
    except Exception:
        # Pillow remains a compatibility fallback if the accelerated backend cannot decode it.
        try:
            with Image.open(raw) as im:
                if im.format!='PNG' or max(im.size)>1800:
                    copy=im.convert('RGB'); copy.thumbnail((1800,1800),Image.Resampling.LANCZOS)
                    vision=raw.with_suffix('.png'); copy.save(vision,'PNG',optimize=True)
        except Exception: pass
    try:
        with Image.open(vision) as im:
            rb=raw.read_bytes(); vb=Path(vision).read_bytes()
            event('image.ready', component='image', stage='decode_transform', outcome='SUCCESS', image_id=key, source_url=url,
                  raw_sha256=hashlib.sha256(rb).hexdigest(), raw_bytes=len(rb), raw_dimensions=[im.width, im.height] if Path(vision)==raw else None,
                  vision_sha256=hashlib.sha256(vb).hexdigest(), vision_bytes=len(vb), vision_dimensions=[im.width, im.height],
                  vision_format=im.format, transformed=(Path(vision)!=Path(raw)))
    except Exception as e:
        event('image.ready', component='image', stage='decode_transform', severity='WARNING', state='warning', outcome='PARTIAL',
              image_id=key, source_url=url, error_type=type(e).__name__, error_message=str(e))
    return str(raw),str(vision),ctype,len(r.content)


def _data_uri(path):
    p=Path(path);mime=mimetypes.guess_type(p.name)[0] or 'image/png';return image_data_uri(p) if p.suffix.lower()=='.png' else f'data:{mime};base64,'+base64.b64encode(p.read_bytes()).decode('ascii')


def _vision_call(name,args,shared,evidence,cancel_event=None):
    cfg=shared['vision_cfg']
    if cancel_event is not None and cancel_event.is_set(): raise WorkflowCancelled('vision start')
    urls=list(args.get('image_urls') or [])
    if args.get('image_url'): urls.insert(0,args['image_url'])
    ids=list(args.get('attachment_ids') or [])
    images=[]
    for aid in ids:
        path=(shared.get('attachments') or {}).get(aid)
        if not path:return {'error':f'Unknown attachment id: {aid}'}
        try:
            p=Path(path).resolve(); p.relative_to(Path(path).resolve().parent)
            if not p.is_file():return {'error':f'Attachment is not a file: {aid}'}
            images.append({'raw':str(p),'vision':str(p),'url':'attachment:'+aid,'bytes':p.stat().st_size})
        except Exception as e:return {'error':f'Attachment read failed: {e}'}
    seen=set()
    for u in urls[:4]:
        if cancel_event is not None and cancel_event.is_set(): raise WorkflowCancelled('vision image download')
        if u in seen:continue
        seen.add(u)
        try:
            raw,vpath,ctype,size=_download_image(u);images.append({'raw':raw,'vision':vpath,'url':u,'bytes':size,'content_type':ctype})
        except Exception as e:return {'error':f'Image download failed: {e}'}
    if not images:return {'error':'No image inputs were supplied.'}
    if cancel_event is not None and cancel_event.is_set(): raise WorkflowCancelled('before Qwen startup')
    MODELS.ensure_vision(cfg)
    prompt=args.get('prompt') or 'Analyze the supplied image(s) carefully. Separate direct visual observations from uncertain interpretation.'
    if shared.get('evidence_snapshot'):prompt += '\n\nRelevant shared evidence (for context only; do not treat it as visual observation):\n'+shared['evidence_snapshot'][:7000]
    content=[{'type':'text','text':prompt}]
    for im in images:content.append({'type':'image_url','image_url':{'url':_data_uri(im['vision'])}})
    workflow('handoff','qwen_start',detail=f'{name} images={len(images)}',role='Qwen3-VL',image_count=len(images))
    resolved_vision_model = resolve_model_path(cfg.get('model',''), 'vision')
    if not resolved_vision_model.is_file():
        return {'error':f'Qwen model file could not be resolved. Configured: {cfg.get("model", "")}\nResolved: {resolved_vision_model}','recoverable':False}
    vp={'model':resolved_vision_model.name,'messages':[{'role':'user','content':content}],'max_completion_tokens':min(int(shared['vision_max_output']),4096),'temperature':min(float(shared['temperature']),0.6),'cache_prompt':False,'parallel_tool_calls':False}
    if shared.get('vision_thinking') not in (None,'','auto'):vp['chat_template_kwargs']={'enable_thinking':shared['vision_thinking'] not in ('none','off','false')}
    try:r=_local_chat(cfg['base_url'],vp,'vision',timeout=900,cancel_event=cancel_event)
    except Exception as e:
        workflow('handoff','qwen_failed','warning',str(e),role='Qwen3-VL');return {'error':str(e),'recoverable':True}
    text=_message(r).get('content','') or ''
    att=[]
    for im in images:
        rec=evidence.add('NEXRAD' if not im['url'].startswith('attachment:') else 'USER','image',{'display_path':im['raw'],'vision_path':im['vision'],'url':im['url'],'bytes':im['bytes']}) if hasattr(evidence,'add') else {'path':im['raw'],'vision_path':im['vision'],'url':im['url'],'bytes':im['bytes']}
        att.append(rec)
    workflow('handoff','qwen_complete',detail=f'{name}',role='Qwen3-VL',image_count=len(images))
    return {'analysis':text,'images':images,'model':'Qwen3-VL 4B Thinking','status':'success'}


def _trusted_url_allowed(url):
    try:
        from urllib.parse import urlparse
        host=(urlparse(str(url)).hostname or '').lower()
        return host == 'weather.gov' or host.endswith('.weather.gov') or host == 'noaa.gov' or host.endswith('.noaa.gov') or host.endswith('.ncei.noaa.gov') or host.endswith('.spc.noaa.gov') or host.endswith('.ncep.noaa.gov') or host.endswith('.nesdis.noaa.gov')
    except Exception:
        return False

def run_tool(name,args,shared,evidence,cancel_event=None,tool_call_id=None):
    if cancel_event is not None and cancel_event.is_set():
        raise WorkflowCancelled('model request')
    tool_span = span(f"tool.{name}", 'tool', tool_name=name, tool_call_id=tool_call_id, arguments=args)
    try:
        write_tool_trace(tool_call_id or f'{name}-{int(time.time()*1000)}', 'arguments.json', args)
        if shared.get('research_mode')=='trusted':
            if name=='web_search':
                result={'error':'Web search is disabled in Trusted Government mode.','recoverable':True}
                tool_span.end('SKIPPED', severity='WARNING', state='warning', detail=result['error'])
                return result
            if name=='fetch_url' and not _trusted_url_allowed(args.get('url','')):
                result={'error':'URL rejected by Trusted Government mode; use an official NOAA/NWS/NCEI/SPC/NCEP/NESDIS source.','recoverable':True}
                tool_span.end('SKIPPED', severity='WARNING', state='warning', detail=result['error'])
                return result
        if name in ('vision_analyze','vision_compare','vision_partner_consult'):
            if name=='vision_partner_consult':
                MODELS.ensure_vision(shared['vision_cfg'])
                prompt=args.get('prompt','')+'\n\nRelevant shared evidence:\n'+shared.get('evidence_snapshot','')[:7000]
                resolved_vision_model = resolve_model_path(shared['vision_cfg'].get('model',''), 'vision')
                if not resolved_vision_model.is_file():
                    raise RuntimeError(f'Qwen model file could not be resolved. Configured: {shared["vision_cfg"].get("model","")}\nResolved: {resolved_vision_model}')
                vp={'model':resolved_vision_model.name,'messages':[{'role':'user','content':prompt}],'max_completion_tokens':min(shared['vision_max_output'],4096),'temperature':0.4,'cache_prompt':False}
                r=_local_chat(shared['vision_cfg']['base_url'],vp,'vision',timeout=900,cancel_event=cancel_event)
                result={'analysis':_message(r).get('content','') or '','status':'success'}
            else:
                result=_vision_call(name,args,shared,evidence,cancel_event=cancel_event)
        else:
            fn=TOOLMAP.get(name)
            if not fn:
                result={'error':f'Unknown tool: {name}','recoverable':False}
            else:
                result=fn(**args)
        if isinstance(result,dict):
            summary={'result_keys':sorted(result.keys())[:80], 'error': bool(result.get('error')), 'result_type':'dict','result_sha256':hashlib.sha256(json_dumps(result).encode('utf-8')).hexdigest() if isinstance(result,dict) else None}
            write_tool_trace(tool_call_id or f'{name}-{int(time.time()*1000)}', 'result.json', result)
            if name=='nwp_model_guidance':
                data=result.get('data') or {}
                fields=(data.get('fields') if isinstance(data,dict) else {}) or {}
                q=(result.get('quantitative_parameters') or {})
                summary.update({
                    'nwp_model':result.get('model'),'cycle_time_utc':result.get('cycle_time_utc'),'forecast_hour':result.get('forecast_hour'),
                    'valid_time_utc':result.get('valid_time_utc'),'requested_fields':result.get('fields_requested',[]),
                    'requested_levels':result.get('levels_requested',[]),'returned_scalar_fields':sorted(fields.keys()),
                    'parsed_record_fields':sorted({str(r.get('name')) for r in (data.get('records') or []) if isinstance(r,dict) and r.get('name')}),
                    'record_count':data.get('record_count'), 'duplicate_field_names':data.get('duplicate_field_names',{}),
                    'quantitative_parameter_keys':sorted(q.keys()),
                    'quantitative_statuses':{k:(v.get('status') if isinstance(v,dict) else None) for k,v in q.items()},
                })
                event('nwp.field_inventory', component='nwp', stage='inventory', outcome='RECORDED', tool=name, **summary)
            tool_span.end('PARTIAL' if result.get('error') else 'SUCCESS', severity='WARNING' if result.get('error') else 'INFO',
                          state='warning' if result.get('error') else 'normal', result_summary=summary)
            return result
        tool_span.end('SUCCESS', result_type=type(result).__name__)
        return result
    except WorkflowCancelled:
        tool_span.end('CANCELLED', severity='WARNING', state='warning', detail='cancelled')
        raise
    except Exception as e:
        write_tool_trace(tool_call_id or f'{name}-error-{int(time.time()*1000)}', 'error.json', {'error_type':type(e).__name__,'error_message':str(e)})
        tool_span.end('FAILED', severity='ERROR', state='error', detail=str(e), error_type=type(e).__name__)
        raise


def build_tools(cfg=None):
    specs=list(TOOL_SPECS)
    if not cfg or cfg.get('research_mode')!='trusted':
        specs=[x for x in specs]
    else:
        specs=[x for x in specs if x.get('function',{}).get('name') not in ('web_search','fetch_url')]
    return specs+VISION_SPECS


def _local_chat(base_url,payload,role='primary',timeout=1800,cancel_event=None,request_id=None,_crash_recovery_attempted=False):
    request_id = request_id or hashlib.sha256(f"{time.time_ns()}:{role}".encode()).hexdigest()[:16]
    model_span = span(f"model.{role}.request", 'model', model_request_id=request_id, role=role, model=payload.get('model'))
    url=base_url.rstrip('/')+'/chat/completions'
    body=json_dumps(payload)
    request_bytes=len(body.encode('utf-8'))
    estimated_prompt_tokens=max(1, round(request_bytes/4))
    workflow('model_request','send',detail=f'{role} bytes={request_bytes} est_tokens={estimated_prompt_tokens}',role=role,request_id=request_id,request_bytes=request_bytes,request_sha256=hashlib.sha256(body.encode('utf-8')).hexdigest(),estimated_tokens=estimated_prompt_tokens)
    write_model_trace(request_id, role, 'request_meta.json', {
        'request_id':request_id,'role':role,'url':url,'request_bytes':request_bytes,
        'request_sha256':hashlib.sha256(body.encode('utf-8')).hexdigest(),
        'estimated_tokens':estimated_prompt_tokens,'model':payload.get('model'),
        'message_count':len(payload.get('messages') or []),'tool_count':len(payload.get('tools') or []),
        'max_completion_tokens':payload.get('max_completion_tokens'),
        'thinking':(payload.get('chat_template_kwargs') or {}),
    })
    t0=time.monotonic()
    if cancel_event is not None and cancel_event.is_set():
        raise WorkflowCancelled('model request')
    try:
        r=requests.post(url,data=body.encode('utf-8'),headers={'Content-Type':'application/json'},timeout=(10,timeout))
    except Exception as e:
        # A llama-server access violation/forced process exit can surface here as a reset connection.
        # Perform exactly one bounded primary recovery using conservative runtime settings.
        if role=='primary' and isinstance(e,(requests.exceptions.ConnectionError, ConnectionResetError)):
            try:
                from .runtime import MODELS
                prim=MODELS.primary
                exit_code=prim.proc.returncode if prim and prim.proc and prim.proc.poll() is not None else None
                if prim and exit_code in (3221225477, -1073741819) and not _crash_recovery_attempted:
                    workflow('model_request','server_crash_detected','warning',f'primary server exited during request; exit_code={exit_code}',role=role,request_id=request_id,exit_code=exit_code)
                    workflow('model_request','network_error','warning',str(e),role=role,request_id=request_id,recovery='conservative_restart')
                    MODELS.recover_primary_after_crash()
                    retry_id=request_id+'-r1'
                    check_cancel = cancel_event.is_set if cancel_event is not None else (lambda: False)
                    if check_cancel(): raise WorkflowCancelled('model request recovery')
                    workflow('model_request','retry_after_crash','normal','retrying same request once after conservative server recovery',role=role,request_id=retry_id,previous_request_id=request_id)
                    return _local_chat(base_url,payload,role=role,timeout=timeout,cancel_event=cancel_event,request_id=retry_id,_crash_recovery_attempted=True)
            except WorkflowCancelled:
                raise
            except Exception as recovery_error:
                workflow('model_request','recovery_failed','error',str(recovery_error),role=role,request_id=request_id)
        workflow('model_request','network_error','error',str(e),role=role,request_id=request_id)
        write_model_trace(request_id, role, 'network_error.txt', str(e))
        model_span.end('FAILED', severity='ERROR', state='error', detail=str(e), error_type=type(e).__name__)
        raise
    elapsed=time.monotonic()-t0
    response_text=r.text
    response_bytes=len(r.content or b'')
    performance({'kind':'model_request','role':role,'elapsed_s':round(elapsed,3),'request_bytes':request_bytes,'estimated_prompt_tokens':estimated_prompt_tokens,'response_bytes':response_bytes,'http_status':r.status_code,'request_id':request_id})
    write_model_trace(request_id, role, 'raw_response.txt', response_text)
    write_model_trace(request_id, role, 'response_http.json', {'status_code':r.status_code,'elapsed_s':round(elapsed,3),'response_bytes':response_bytes,'response_sha256':hashlib.sha256((r.content or b'')).hexdigest(),'content_type':r.headers.get('content-type',''),'request_id':request_id})
    if r.status_code>=400:
        workflow('model_request','http_error','error',f'{role} HTTP {r.status_code}: {response_text[:2500]}',role=role,request_id=request_id)
        model_span.end('FAILED', severity='ERROR', state='error', detail=f'HTTP {r.status_code}', http_status=r.status_code, response_bytes=response_bytes)
        raise RuntimeError(f'{role} local model HTTP {r.status_code}: {response_text[:2500]}')
    try:
        parsed=r.json()
    except Exception as e:
        workflow('model_request','json_decode_error','error',str(e),role=role,request_id=request_id,raw_preview=response_text[:5000],raw_length=len(response_text))
        write_model_trace(request_id, role, 'json_error.json', {'error':str(e),'raw_preview':response_text[:12000],'raw_length':len(response_text)})
        model_span.end('FAILED', severity='ERROR', state='error', detail=str(e), error_type=type(e).__name__, response_bytes=response_bytes)
        raise RuntimeError(f'{role} returned malformed JSON: {e}') from e
    try:
        choices=parsed.get('choices') or []
        first=choices[0] if choices else {}
        message=first.get('message') or {}
        diag={
            'request_id':request_id,'choices_count':len(choices),'top_level_keys':sorted(parsed.keys()) if isinstance(parsed,dict) else [],
            'choice_keys':sorted(first.keys()) if isinstance(first,dict) else [],
            'message_keys':sorted(message.keys()) if isinstance(message,dict) else [],
            'finish_reason':first.get('finish_reason') if isinstance(first,dict) else None,
            'content_type':type(message.get('content')).__name__ if isinstance(message,dict) and 'content' in message else None,
            'content_length':len(message.get('content') or '') if isinstance(message,dict) and isinstance(message.get('content'),str) else 0,
            'reasoning_content_length':len(message.get('reasoning_content') or '') if isinstance(message,dict) and isinstance(message.get('reasoning_content'),str) else 0,
            'thinking_length':len(message.get('thinking') or '') if isinstance(message,dict) and isinstance(message.get('thinking'),str) else 0,
            'tool_call_count':len(message.get('tool_calls') or []) if isinstance(message,dict) else 0,
        }
        workflow('model_response','parsed','normal',detail=f"{role} request_id={request_id} content={diag['content_length']} reasoning={diag['reasoning_content_length']} thinking={diag['thinking_length']} tool_calls={diag['tool_call_count']} finish={diag['finish_reason']}",**diag)
        write_model_trace(request_id, role, 'response_shape.json', diag)
        usage=parsed.get('usage') if isinstance(parsed,dict) else None
        timings=parsed.get('timings') if isinstance(parsed,dict) else None
        response_meta={'usage':usage,'timings':timings,'system_fingerprint':parsed.get('system_fingerprint') if isinstance(parsed,dict) else None,
                       'provider_model':parsed.get('model') if isinstance(parsed,dict) else None}
        write_model_trace(request_id, role, 'response_meta.json', response_meta)
        workflow('model_response','metrics','normal',detail=f"{role} request_id={request_id}",role=role,request_id=request_id,
                 http_status=r.status_code,response_bytes=response_bytes,elapsed_ms=round(elapsed*1000,3),
                 reported_prompt_tokens=(usage or {}).get('prompt_tokens') if isinstance(usage,dict) else None,
                 reported_completion_tokens=(usage or {}).get('completion_tokens') if isinstance(usage,dict) else None,
                 reported_total_tokens=(usage or {}).get('total_tokens') if isinstance(usage,dict) else None,
                 cached_tokens=((usage or {}).get('prompt_tokens_details') or {}).get('cached_tokens') if isinstance(usage,dict) else None,
                 timings=timings)
        model_span.end('SUCCESS' if (diag.get('finish_reason') not in ('length','content_filter') and diag.get('content_length',0)>0) else 'PARTIAL',
                       severity='WARNING' if diag.get('finish_reason')=='length' else 'INFO', state='warning' if diag.get('finish_reason')=='length' else 'normal',
                       detail=f"finish={diag.get('finish_reason')}", **response_meta, content_length=diag.get('content_length'),
                       reasoning_content_length=diag.get('reasoning_content_length'), tool_call_count=diag.get('tool_call_count'))
    except Exception as e:
        workflow('model_response','diagnostic_failed','warning',str(e),role=role,request_id=request_id)
        model_span.end('PARTIAL', severity='WARNING', state='warning', detail=str(e))
    parsed['_meteorology_request_id']=request_id
    return parsed


def _message(resp):
    choices=resp.get('choices') or []
    if not choices:
        workflow('model_response','invalid','error','Local model returned no choices.',request_id=resp.get('_meteorology_request_id'))
        raise RuntimeError('Local model returned no choices.')
    first=choices[0] or {}
    msg=first.get('message') or {}
    if not isinstance(msg,dict):
        workflow('model_response','invalid','error','Local model returned an invalid message object.',request_id=resp.get('_meteorology_request_id'),message_type=type(msg).__name__)
        raise RuntimeError('Local model returned an invalid message object.')
    workflow('model_response','message_extracted','normal',detail=f"request_id={resp.get('_meteorology_request_id','')} keys={','.join(sorted(msg.keys()))}",request_id=resp.get('_meteorology_request_id'),message_keys=sorted(msg.keys()))
    return msg


def _message_text(msg):
    """Extract only user-facing text from common OpenAI-compatible message shapes.

    Reasoning/thinking content is intentionally never promoted to the final answer.
    """
    if not isinstance(msg,dict):
        return ''
    candidates=[]
    content=msg.get('content')
    if isinstance(content,str):
        candidates.append(content)
    elif isinstance(content,list):
        # Some OpenAI-compatible servers use structured content parts.
        parts=[]
        for part in content:
            if isinstance(part,str):
                parts.append(part)
            elif isinstance(part,dict):
                text=part.get('text')
                if isinstance(text,str):
                    parts.append(text)
        if parts:
            candidates.append(''.join(parts))
    for key in ('text','final_text','response'):
        value=msg.get(key)
        if isinstance(value,str):
            candidates.append(value)
    for value in candidates:
        if value.strip():
            return value
    return ''


def _recovery_payload(messages, model, configured_max_output, temperature, context_limit, base_url=''):
    """Create a bounded final-answer request after an empty-content completion."""
    recovery_prompt={
        'role':'user',
        'content':(
            'FINAL ANSWER RECOVERY: Your previous model turn did not contain usable user-facing text. '
            'Provide ONLY the final answer to my original request now, using the verified evidence already present in this conversation. '
            'Do not make another tool call. Do not expose hidden reasoning. Do not return an empty response.'
        )
    }
    final_msgs=compact_messages(messages,12000,4)
    final_msgs.append(recovery_prompt)
    # Recovery is deliberately less reasoning-heavy so a reasoning-only stop cannot consume the entire turn.
    payload, safe_output=_fit_primary_payload(final_msgs,[],model,configured_max_output,temperature,'low',context_limit,999,base_url=base_url)
    payload['max_completion_tokens']=min(safe_output,configured_max_output)
    return payload


def _final_text_or_error(msg, request_id):
    text=_message_text(msg)
    if text.strip():
        return text
    workflow('model_response','empty_final','warning',detail=f'no user-facing text request_id={request_id}',request_id=request_id,
             finish_reason=msg.get('_finish_reason') if isinstance(msg,dict) else None,
             message_keys=sorted(msg.keys()) if isinstance(msg,dict) else [])
    return ''

def _thinking_payload(value):
    # GPT-OSS's llama.cpp template natively documents reasoning_effort via template kwargs.
    if value in (None,'','auto'):return {}
    return {'chat_template_kwargs':{'reasoning_effort':value}}


def _make_assistant_result(content,request_id=None):
    class M:pass
    class C:pass
    class R:pass
    m=M();m.content=content;c=C();c.message=m;out=R();out.choices=[c]
    out._meteorology_request_id=request_id
    out._meteorology_text_length=len(content or '')
    return out


def _count_server_tokens(base_url, payload):
    """Ask the running llama.cpp server for its authoritative chat input-token count.

    Falls back to None when the endpoint is unavailable so the caller can retain the
    conservative local estimator. This endpoint is supported by current llama.cpp
    servers and counts the same chat-completions payload shape we actually send.
    """
    if not base_url:
        return None
    try:
        url=base_url.rstrip('/')+'/chat/completions/input_tokens'
        body=json_dumps(payload)
        r=requests.post(url,data=body.encode('utf-8'),headers={'Content-Type':'application/json'},timeout=(2,5))
        if not r.ok:
            return None
        obj=r.json()
        value=obj.get('input_tokens') if isinstance(obj,dict) else None
        return int(value) if value is not None else None
    except Exception:
        return None


def _compact_stats(before, after):
    before_msgs=list(before or [])
    after_msgs=list(after or [])
    def role_counts(items):
        out={}
        for m in items:
            if isinstance(m,dict):
                r=str(m.get('role','unknown')); out[r]=out.get(r,0)+1
        return out
    rb=role_counts(before_msgs); ra=role_counts(after_msgs)
    return {
        'messages_before':len(before_msgs),
        'messages_after':len(after_msgs),
        'messages_removed':max(0,len(before_msgs)-len(after_msgs)),
        'message_chars_before':sum(len(str(m.get('content','') or '')) for m in before_msgs if isinstance(m,dict)),
        'message_chars_after':sum(len(str(m.get('content','') or '')) for m in after_msgs if isinstance(m,dict)),
        'message_chars_removed':max(0,sum(len(str(m.get('content','') or '')) for m in before_msgs if isinstance(m,dict))-sum(len(str(m.get('content','') or '')) for m in after_msgs if isinstance(m,dict))),
        'tool_messages_before':rb.get('tool',0), 'tool_messages_after':ra.get('tool',0),
        'user_messages_before':rb.get('user',0), 'user_messages_after':ra.get('user',0),
        'assistant_messages_before':rb.get('assistant',0), 'assistant_messages_after':ra.get('assistant',0),
        'system_messages_before':rb.get('system',0), 'system_messages_after':ra.get('system',0),
        'system_chars_before':sum(len(str(m.get('content','') or '')) for m in before_msgs if isinstance(m,dict) and m.get('role')=='system'),
        'system_chars_after':sum(len(str(m.get('content','') or '')) for m in after_msgs if isinstance(m,dict) and m.get('role')=='system'),
        'user_chars_before':sum(len(str(m.get('content','') or '')) for m in before_msgs if isinstance(m,dict) and m.get('role')=='user'),
        'user_chars_after':sum(len(str(m.get('content','') or '')) for m in after_msgs if isinstance(m,dict) and m.get('role')=='user'),
        'tool_chars_before':sum(len(str(m.get('content','') or '')) for m in before_msgs if isinstance(m,dict) and m.get('role')=='tool'),
        'tool_chars_after':sum(len(str(m.get('content','') or '')) for m in after_msgs if isinstance(m,dict) and m.get('role')=='tool'),
        'compaction_applied':len(before_msgs)!=len(after_msgs),
    }


def _fit_primary_payload(messages, tools, model, max_output, temperature, thinking, context_limit, round_number, base_url=''):
    """Fit a primary request around the actual GPT-OSS context budget.

    The system prompt and current task are protected by compact_messages(). The function
    uses a conservative byte/4 estimate for fast candidate selection, then asks the running
    llama.cpp server for an authoritative input-token count when its token-count endpoint is
    available. The authoritative count is used for the final budget decision.
    """
    margin_tokens=1024
    targets=(48000,42000,36000,32000,28000,24000,20000,16000,12000,8000,4000,2400,1600,1200)
    original_messages=list(messages or [])
    chosen=None
    exact_used=False

    for target in targets:
        candidate_msgs=compact_messages(original_messages,target,8)
        if not candidate_msgs and original_messages:
            essential=[original_messages[0]] if original_messages[0].get('role')=='system' else []
            if original_messages and (not essential or original_messages[-1] is not original_messages[0]):
                essential.append(original_messages[-1])
            candidate_msgs=essential
        payload={
            'model':model,'messages':candidate_msgs,'tools':tools,
            'max_completion_tokens':max_output,'temperature':temperature,
            'parallel_tool_calls':False,'cache_prompt':True
        }
        payload.update(_thinking_payload(thinking))
        payload_bytes=_json_size(payload)
        estimated=max(1,round(payload_bytes/4))
        # Use the cheap estimate to avoid an unnecessary tokenization HTTP call when the
        # candidate is obviously too large for the configured context.
        if estimated + 256 + margin_tokens > context_limit:
            chosen=(payload,payload_bytes,estimated,target,candidate_msgs,False)
            continue
        chosen=(payload,payload_bytes,estimated,target,candidate_msgs,False)
        exact=_count_server_tokens(base_url,payload)
        if exact is not None:
            exact_used=True
            chosen=(payload,payload_bytes,exact,target,candidate_msgs,True)
            if exact + max_output + margin_tokens <= context_limit:
                break
            # Too much prompt for the requested output; try a more compact message set.
            continue
        # No authoritative count available; the conservative estimate controls the decision.
        if estimated + max_output + margin_tokens <= context_limit:
            break

    if chosen is None:
        raise RuntimeError('GPT-OSS context fitter could not construct a request payload.')

    payload,payload_bytes,prompt_tokens,used_chars,candidate_msgs,exact_used=chosen
    # Re-count the selected candidate when it was only kept as an obviously-too-large
    # estimate, up to the first compacted candidate that can mathematically fit a small answer.
    if exact_used and prompt_tokens + margin_tokens + 256 > context_limit:
        raise RuntimeError(
            f'GPT-OSS context budget exhausted before generation: measured prompt {prompt_tokens} tokens, '
            f'context limit {context_limit}. The protected system/current task content cannot be safely compacted further.'
        )

    available_output=context_limit-prompt_tokens-margin_tokens
    if available_output < 256:
        raise RuntimeError(
            f'GPT-OSS context budget exhausted before generation: prompt {prompt_tokens} tokens, '
            f'context limit {context_limit}, available output {available_output} tokens.'
        )

    safe_output=min(int(max_output),int(available_output))
    if safe_output < 256:
        raise RuntimeError(
            f'GPT-OSS context budget could not be safely satisfied after output adjustment: '
            f'prompt {prompt_tokens}, context {context_limit}.'
        )
    payload['max_completion_tokens']=safe_output
    payload_bytes=_json_size(payload)

    # Changing max_completion_tokens does not change input-token count, so prompt_tokens remains valid.
    state='normal'
    stats=_compact_stats(original_messages,candidate_msgs)
    workflow('context','budget',state,detail=(
        f'round={round_number} payload_bytes={payload_bytes} est_prompt_tokens={max(1,round(payload_bytes/4))} '
        f'input_tokens={prompt_tokens} token_count_method={"server" if exact_used else "estimate"} '
        f'max_output_tokens={safe_output} context_limit={context_limit} reserved_margin={margin_tokens} '
        f'message_char_budget={used_chars}'
    ),round=round_number,payload_bytes=payload_bytes,estimated_tokens=max(1,round(payload_bytes/4)),
    input_tokens=prompt_tokens,token_count_method='server' if exact_used else 'estimate',
    max_output_tokens=safe_output,context_limit=context_limit,reserved_margin=margin_tokens,
    message_char_budget=used_chars,tool_schema_bytes=_json_size(tools),tool_schema_chars=len(json_dumps(tools)),system_prompt_chars=stats.get('system_chars_after'),current_user_chars=stats.get('user_chars_after'),**stats)
    return payload,safe_output


def run(cfg,messages,ws=None,mem=None,attachments=None,stage_cb=None,cancel_event=None,conversation_id=None):
    trace = start_trace(conversation_id=conversation_id or (messages[0].get('conversation_id') if messages and isinstance(messages[0],dict) else None), name='meteorology_request')
    try:
        result = _run_traced(cfg,messages,ws,mem,attachments,stage_cb,cancel_event,trace)
        finish_trace('SUCCESS')
        return result
    except WorkflowCancelled as e:
        finish_trace('CANCELLED', error_code='CANCELLATION', detail=str(e))
        raise
    except Exception as e:
        finish_trace('FAILED', error_code=type(e).__name__, detail=str(e))
        raise
    finally:
        from .logging_utils import clear_trace_context
        clear_trace_context()


def _run_traced(cfg,messages,ws=None,mem=None,attachments=None,stage_cb=None,cancel_event=None,trace=None):
    def check_cancel(stage='workflow'):
        if cancel_event is not None and cancel_event.is_set():
            workflow('cancel','requested',detail=stage,state='warning')
            raise WorkflowCancelled(stage)
    primary_cfg = cfg['primary']
    check_cancel('starting primary model')
    MODELS.ensure_primary(primary_cfg)
    base=primary_cfg['base_url']
    resolved_model = resolve_model_path(primary_cfg.get('model',''), 'primary')
    if not resolved_model.is_file():
        raise RuntimeError(f'GPT-OSS model file could not be resolved. Configured: {primary_cfg.get("model", "")}\nResolved: {resolved_model}')
    model=resolved_model.name
    context_limit=max(8192,int(primary_cfg.get('context',32768))); configured_max_output=min(int(cfg.get('max_output_tokens',8192)),16384)
    temperature=float(cfg.get('temperature',0.7));thinking=cfg.get('thinking','medium')
    msgs=[{'role':'system','content':system_prompt(cfg,ws,mem)+'\n\nRUNTIME EVIDENCE RULE: For layer-dependent quantities, use only explicit layer metadata or the tool-provided quantitative_parameters status. Never infer a layer from an unlabeled scalar field. Mark application calculations as DERIVED; do not describe derived values as DIRECT.'}]
    attachment_ids=sorted((attachments or {}).keys())
    if attachment_ids:msgs.append({'role':'system','content':'User image attachments are available to the vision specialist. Use attachment_ids only when image inspection is necessary. IDs: '+json.dumps(attachment_ids,ensure_ascii=False)})
    for m in messages[-8:]:
        role=m.get('role')
        if role=='user':
            msgs.append({'role':'user','content':str(m.get('content',''))})
        elif role=='assistant':
            msgs.append(_normalize_assistant_message({'role':'assistant','content':m.get('content','')}))
    cache={};failure_counts={};evidence=__import__('meteorology_ai.collaboration',fromlist=['EvidenceBus']).EvidenceBus()
    evidence_snapshot=''; maxrounds=max(4,min(int(cfg.get('tool_loop_max',10)),12)); tools=build_tools(cfg); started=time.monotonic()
    for i in range(1,maxrounds+1):
        check_cancel(f'before reasoning round {i}')
        TELEMETRY.round(i);workflow('reasoning','GPT-OSS',detail=f'round={i}',iteration=i)
        payload,max_output_for_round=_fit_primary_payload(msgs,tools,model,configured_max_output,temperature,thinking,context_limit,i,base_url=base)
        payload_bytes=_json_size(payload)
        audit_id=f'primary-r{i}-{int(time.time()*1000)}'
        write_prompt_audit(payload.get('messages',[{}])[0].get('content',''), cfg, ws, request_id=audit_id)
        # Persist a compact request snapshot as well as the exact system prompt; never omit
        # this on failures because it is needed to reproduce context/serialization issues.
        write_model_trace(audit_id,'primary','request_snapshot.json',{
            'model':payload.get('model'),'message_count':len(payload.get('messages') or []),
            'tool_count':len(payload.get('tools') or []),'request_bytes':payload_bytes,
            'estimated_tokens':max(1,round(payload_bytes/4)),'messages':[
                {'role':m.get('role'),'content_chars':len(m.get('content') or '') if isinstance(m,dict) else 0,
                 'tool_call_count':len(m.get('tool_calls') or []) if isinstance(m,dict) else 0}
                for m in (payload.get('messages') or [])
            ]
        })
        check_cancel(f'before GPT-OSS request round {i}')
        resp=_local_chat(base,payload,'primary',timeout=1800,cancel_event=cancel_event,request_id=audit_id);check_cancel(f'after GPT-OSS request round {i}');msg=_normalize_assistant_message(_message(resp));calls=msg.get('tool_calls') or []
        if not calls:
            text=_message_text(msg)
            if text.strip():
                workflow('model_response','final_text','normal',detail=f'round={i} chars={len(text)} request_id={resp.get("_meteorology_request_id","")}',round=i,text_length=len(text),request_id=resp.get('_meteorology_request_id'))
                workflow('workflow','completed','normal',detail=f'round={i} request_id={resp.get("_meteorology_request_id","")}',round=i,request_id=resp.get('_meteorology_request_id'))
                return _make_assistant_result(text,resp.get('_meteorology_request_id')),evidence.evidence
            # A completed round with no tool call but no final content is not a valid
            # user-facing answer. Force one bounded final synthesis from the evidence
            # already gathered rather than returning a blank assistant message.
            workflow('model_response','empty_content','warning',f'round={i}; bounded final-answer recovery',role='primary')
            final_text=''
            final_resp=None
            for attempt in range(1,3):
                recovery_id=f'primary-recovery-r{i}-a{attempt}-{int(time.time()*1000)}'
                final_payload=_recovery_payload(msgs,model,configured_max_output,temperature,context_limit,base_url=base)
                # Preserve exact system prompt for each recovery request.
                write_prompt_audit(final_payload.get('messages',[{}])[0].get('content',''), cfg, ws, request_id=recovery_id)
                write_model_trace(recovery_id,'primary','request_snapshot.json',{'model':model,'message_count':len(final_payload.get('messages') or []),'tool_count':0,'request_bytes':_json_size(final_payload),'estimated_tokens':max(1,round(_json_size(final_payload)/4)),'recovery_attempt':attempt})
                check_cancel(f'before empty-content recovery attempt {attempt}')
                final_resp=_local_chat(base,final_payload,'primary',timeout=1800,cancel_event=cancel_event,request_id=recovery_id)
                final_msg=_message(final_resp)
                final_text=_message_text(final_msg)
                if final_text.strip():
                    workflow('model_response','final_text','normal',detail=f'empty-content recovery chars={len(final_text)} request_id={final_resp.get("_meteorology_request_id","")} attempt={attempt}',round=i,text_length=len(final_text),request_id=final_resp.get('_meteorology_request_id'),recovery_attempt=attempt)
                    workflow('workflow','completed','normal',detail=f'empty-content recovery round={i} request_id={final_resp.get("_meteorology_request_id","")}',round=i,request_id=final_resp.get('_meteorology_request_id'))
                    return _make_assistant_result(final_text,final_resp.get('_meteorology_request_id')),evidence.evidence
                workflow('model_response','empty_recovery_attempt','warning',detail=f'attempt={attempt} returned no user-facing text request_id={final_resp.get("_meteorology_request_id","")}',request_id=final_resp.get('_meteorology_request_id'),recovery_attempt=attempt)
            raise RuntimeError('GPT-OSS completed but returned no final user-facing text after two bounded recovery attempts.')
        msgs.append(msg)
        results={};pending=[]
        for call in calls:
            name=(call.get('function') or {}).get('name','');raw=(call.get('function') or {}).get('arguments','{}');args,err=_parse_args(raw,name);cid=call.get('id','')
            if err:results[cid]={'error':err,'recoverable':True};continue
            key=(name,json.dumps(args,sort_keys=True,ensure_ascii=False,default=str))
            if key in cache:results[cid]=deepcopy(cache[key])
            elif failure_counts.get(key,0)>=2:results[cid]={'error':'Identical tool request already failed twice in this workflow; use a different method or continue without it.','recoverable':True}
            else:pending.append((call,args,key))
        if pending:
            check_cancel(f'before tools round {i}')
            shared={'vision_cfg':cfg['vision'],'evidence_snapshot':evidence.snapshot(7000),'max_output_tokens':configured_max_output,'vision_max_output':min(configured_max_output,4096),'temperature':temperature,'thinking':thinking,'vision_thinking':'on','attachments':attachments or {},'research_mode':cfg.get('research_mode','normal')}
            # Parallelize only independent non-vision weather tools; vision stays sequential to protect a small local VLM.
            vision_pending=[x for x in pending if x[0].get('function',{}).get('name','').startswith('vision_')]
            other_pending=[x for x in pending if x not in vision_pending]
            ordered_futures=[]
            if other_pending:
                with ThreadPoolExecutor(max_workers=min(3,len(other_pending))) as ex:
                    fs={}
                    for c,a,k in other_pending:
                        nm=c.get('function',{}).get('name','');TELEMETRY.tool_start(nm)
                        # Context variables do not automatically cross ThreadPoolExecutor workers.
                        # Copy the current workflow trace into each tool worker so every event remains correlated.
                        worker_ctx=contextvars.copy_context()
                        fs[ex.submit(worker_ctx.run,run_tool,nm,a,shared,evidence,cancel_event,c.get('id',''))]=(c,a,k)
                    for fut in as_completed(fs):
                        c,a,k=fs[fut];cid=c.get('id','');name=c.get('function',{}).get('name','')
                        try:
                            res=fut.result(); check_cancel(f'after tool {name}'); workflow('tool','complete',detail=name,tool=name); TELEMETRY.tool_complete(name)
                        except Exception as e:
                            if cancel_event is not None and cancel_event.is_set():
                                raise WorkflowCancelled(f'cancelled during tool {name}')
                            res={'error':str(e),'recoverable':True};workflow('tool','failed','warning',str(e),tool=name);failure_counts[k]=failure_counts.get(k,0)+1
                        cache[k]=res;results[cid]=res
            for c,a,k in vision_pending:
                check_cancel(f'before vision tool {c.get("function",{}).get("name","vision")}')
                cid=c.get('id','');name=c.get('function',{}).get('name','')
                TELEMETRY.tool_start(name)
                try:
                    if name.startswith('vision_'):TELEMETRY.qwen_start(name)
                    res=run_tool(name,a,shared,evidence,cancel_event=cancel_event,tool_call_id=cid); check_cancel(f'after tool {name}'); workflow('tool','complete',detail=name,tool=name);
                    if name.startswith('vision_'):TELEMETRY.qwen_complete(name)
                    TELEMETRY.tool_complete(name)
                except Exception as e:
                    if cancel_event is not None and cancel_event.is_set():
                        raise WorkflowCancelled(f'cancelled during tool {name}')
                    res={'error':str(e),'recoverable':True};workflow('tool','failed','warning',str(e),tool=name);failure_counts[k]=failure_counts.get(k,0)+1
                cache[k]=res;results[cid]=res
        for call in calls:
            cid=call.get('id','');name=(call.get('function') or {}).get('name','');res=results.get(cid,{'error':'Tool returned no result.','recoverable':True})
            if isinstance(res,dict) and not res.get('error'):evidence.add('tool',name,res)
            else:TELEMETRY.update(f'{name} warning',min(89,max(5,TELEMETRY.snapshot()['percent']+4)),'warning',str(res.get('error','tool warning')),warning=True)
            msgs.append({'role':'tool','tool_call_id':cid,'content':_safe_tool_result(res)})
        check_cancel(f'before tool-result synthesis round {i}')
        evidence_snapshot=evidence.snapshot(7000)
        msgs=compact_messages(msgs,48000,8)
    # Final synthesis is an answer-only turn. Do not give GPT-OSS tools at this stage;
    # explicitly tell it that it must answer from the verified evidence already gathered.
    # A low reasoning setting prevents the model from consuming the entire turn planning
    # another tool call when tools are intentionally unavailable.
    msgs.append({'role':'user','content':(
        'FINAL SYNTHESIS: Provide the best complete user-facing answer now using only the verified evidence already present in this conversation. '
        'No tools are available in this stage. Do not request, plan, simulate, or discuss another tool call. '
        'Do not expose hidden reasoning. Do not return an empty answer. If some requested information is unavailable, state that clearly.'
    )})
    final_id=f'primary-final-{int(time.time()*1000)}'
    final_thinking='low'
    final_payload, final_output=_fit_primary_payload(msgs,[],model,configured_max_output,temperature,final_thinking,context_limit,maxrounds+1,base_url=base)
    final_payload['max_completion_tokens']=min(final_output, configured_max_output)
    write_prompt_audit(final_payload.get('messages',[{}])[0].get('content',''), cfg, ws, request_id=final_id)
    write_model_trace(final_id,'primary','request_snapshot.json',{'model':model,'message_count':len(final_payload.get('messages') or []),'tool_count':0,'request_bytes':_json_size(final_payload),'estimated_tokens':max(1,round(_json_size(final_payload)/4))})
    check_cancel('before final synthesis')
    resp=_local_chat(base,final_payload,'primary',timeout=1800,cancel_event=cancel_event,request_id=final_id)
    final_msg=_message(resp); final_msg['_finish_reason']=((resp.get('choices') or [{}])[0].get('finish_reason') if isinstance(resp,dict) else None); final_text=_message_text(final_msg)
    if not final_text.strip():
        # Final synthesis may still stop after consuming reasoning without emitting content.
        # Reuse the bounded recovery path once, with low reasoning and no tools.
        workflow('model_response','final_empty','warning',detail=f'final synthesis empty request_id={resp.get("_meteorology_request_id","")}',request_id=resp.get('_meteorology_request_id'),finish_reason=final_msg.get('_finish_reason'))
        recovery_id=f'primary-final-recovery-{int(time.time()*1000)}'
        recovery_payload=_recovery_payload(msgs,model,configured_max_output,temperature,context_limit,base_url=base)
        write_prompt_audit(recovery_payload.get('messages',[{}])[0].get('content',''), cfg, ws, request_id=recovery_id)
        write_model_trace(recovery_id,'primary','request_snapshot.json',{'model':model,'message_count':len(recovery_payload.get('messages') or []),'tool_count':0,'request_bytes':_json_size(recovery_payload),'estimated_tokens':max(1,round(_json_size(recovery_payload)/4)),'recovery_attempt':1,'final_synthesis_recovery':True})
        check_cancel('before final synthesis recovery')
        recovery_resp=_local_chat(base,recovery_payload,'primary',timeout=1800,cancel_event=cancel_event,request_id=recovery_id)
        recovery_msg=_message(recovery_resp); recovery_msg['_finish_reason']=((recovery_resp.get('choices') or [{}])[0].get('finish_reason') if isinstance(recovery_resp,dict) else None)
        recovery_text=_message_text(recovery_msg)
        if recovery_text.strip():
            workflow('model_response','final_text','normal',detail=f'final synthesis recovery chars={len(recovery_text)} request_id={recovery_id}',text_length=len(recovery_text),request_id=recovery_id,recovery_attempt=1)
            workflow('workflow','completed','normal',detail=f'final synthesis recovery request_id={recovery_id}',round=maxrounds+1,request_id=recovery_id)
            return _make_assistant_result(recovery_text,recovery_id),evidence.evidence
        workflow('model_response','final_recovery_empty','error',detail=f'final synthesis recovery empty request_id={recovery_id}',request_id=recovery_id)
        raise RuntimeError('GPT-OSS completed final synthesis but returned no user-facing text after a bounded recovery attempt.')
    workflow('model_response','final_text','normal',detail=f'final synthesis chars={len(final_text)} request_id={resp.get("_meteorology_request_id","")}',text_length=len(final_text),request_id=resp.get('_meteorology_request_id'))
    workflow('workflow','completed','normal',detail=f'final synthesis request_id={resp.get("_meteorology_request_id","")}',round=maxrounds+1,request_id=resp.get('_meteorology_request_id'))
    return _make_assistant_result(final_text,resp.get('_meteorology_request_id')),evidence.evidence
