from __future__ import annotations
import hashlib,json,threading
from .backend import json_dumps
from datetime import datetime,timezone
from pathlib import Path
from .config import APP_DIR
CODE_ROOT=Path(__file__).resolve().parents[1]
SAFE_APP_FILES={'app.py','requirements.txt','README.md','MeteorologyAI.spec','run_windows.bat','install_windows.bat','install2_windows.bat','install2_requirements.py','build_windows.bat'}
SAFE_APP_FILES |= {f'meteorology_ai/{x}' for x in ('__init__.py','client.py','config.py','storage.py','ui.py','weather_tools.py','runtime.py','models.py','orchestrator.py','collaboration.py','telemetry.py','performance.py','logging_utils.py')}

def inspect_application(files=None,max_chars_per_file=7000,max_total_chars=28000):
 selected=[str(x).replace('\\','/') for x in (files or [])] or ['app.py','requirements.txt','meteorology_ai/orchestrator.py','meteorology_ai/weather_tools.py','meteorology_ai/runtime.py','meteorology_ai/ui.py']
 total=0;out=[]
 for rel in selected:
  if rel not in SAFE_APP_FILES: out.append({'path':rel,'error':'rejected: file not on safe application allowlist'});continue
  p=(CODE_ROOT/rel).resolve()
  try:p.relative_to(CODE_ROOT.resolve())
  except ValueError:out.append({'path':rel,'error':'rejected: path escape'});continue
  if not p.is_file():out.append({'path':rel,'error':'file not found'});continue
  text=p.read_text(encoding='utf-8',errors='replace'); lim=max(1000,min(int(max_chars_per_file),10000)); remaining=max(0,int(max_total_chars)-total); text=text[:min(lim,remaining)]; total+=len(text);out.append({'path':rel,'bytes':p.stat().st_size,'text':text,'truncated':p.stat().st_size>len(text)})
  if total>=max_total_chars:break
 return {'application_root':str(CODE_ROOT),'data_root':str(APP_DIR),'files':out,'total_chars':total,'note':'Only explicitly allowlisted application files are exposed.'}

class EvidenceBus:
 def __init__(self):self.lock=threading.RLock();self.evidence=[];self.events=[];self.handoffs=[]
 def add(self,source,kind,payload,provenance=None):
  raw=json_dumps(payload); eid=f'{source}:{kind}:{hashlib.sha1(raw.encode()).hexdigest()[:10]}'; item={'id':eid,'source':source,'kind':kind,'payload':payload,'provenance':provenance or {}}
  with self.lock:self.evidence.append(item);return item
 def event(self,kind,stage,detail='',state='normal',**extra):
  x={'time':datetime.now(timezone.utc).isoformat(),'kind':kind,'stage':stage,'detail':str(detail),'state':state};x.update(extra)
  with self.lock:self.events.append(x);return x
 def handoff(self,sender,receiver,purpose,context_ids):
  x={'time':datetime.now(timezone.utc).isoformat(),'sender':sender,'receiver':receiver,'purpose':purpose,'context_ids':list(context_ids)}
  with self.lock:self.handoffs.append(x);return x
 def snapshot(self,max_chars=12000):
  with self.lock:obj={'evidence':self.evidence[-20:],'events':self.events[-40:],'handoffs':self.handoffs[-20:]}
  return json_dumps(obj)[:max_chars]
