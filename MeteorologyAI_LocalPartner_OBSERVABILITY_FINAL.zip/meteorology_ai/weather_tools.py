import json
import math
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlencode

import requests
from .backend import compatible_unit

TOOL_SOURCE_LOG = []
UA = 'MeteorologyAI/1.1'
NWS = 'https://api.weather.gov'
NCEI = 'https://www.ncei.noaa.gov/access/services/data/v1'
NOMADS = 'https://nomads.ncep.noaa.gov/cgi-bin'


def get(url, params=None, headers=None, timeout=30):
    h = {'User-Agent': UA, 'Accept': 'application/json'}
    h.update(headers or {})
    r = requests.get(url, params=params, headers=h, timeout=timeout)
    r.raise_for_status()
    return r


def src(url, title):
    return {'title': title, 'url': url}

def web_search(query: str, max_results: int = 6):
    """Search the public web for current information and return compact result titles, URLs, and snippets. No AI API is used."""
    query=str(query).strip()
    if not query: raise ValueError('Search query cannot be empty.')
    max_results=max(1,min(int(max_results),10))
    u='https://html.duckduckgo.com/html/'
    r=get(u, {'q': query}, headers={'Accept':'text/html,application/xhtml+xml'})
    from urllib.parse import unquote
    text=r.text
    results=[]
    for m in re.finditer(r'class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>',text,re.I|re.S):
        url=unquote(re.sub('<.*?>','',m.group(1)));title=re.sub('<.*?>','',m.group(2)).strip()
        tail=text[m.end():m.end()+2500];sm=re.search(r'class=\"result__snippet\"[^>]*>(.*?)</',tail,re.I|re.S);snippet=re.sub('<.*?>',' ',sm.group(1)).strip() if sm else ''
        results.append({'title':re.sub(r'\s+',' ',title),'url':url,'snippet':re.sub(r'\s+',' ',snippet)})
        if len(results)>=max_results:break
    out={'query':query,'results':results,'sources':[src(r.url,'Web search results')]}
    record_sources(out['sources']);return out


def record_sources(items):
    TOOL_SOURCE_LOG.extend(items or [])


def _compact(v):
    if isinstance(v, dict):
        return {k: _compact(x) for k, x in v.items() if x not in (None, '', [], {})}
    if isinstance(v, list):
        return [_compact(x) for x in v]
    return v


def nws_point_weather(latitude: float, longitude: float):
    """Get compact current NWS forecast, hourly forecast metadata, and grid information for a U.S. latitude/longitude."""
    u = f'{NWS}/points/{latitude:.4f},{longitude:.4f}'
    p = get(u).json()['properties']
    forecast = get(p['forecast']).json() if p.get('forecast') else {}
    hourly = get(p['forecastHourly']).json() if p.get('forecastHourly') else {}
    periods = forecast.get('properties', {}).get('periods', [])
    hperiods = hourly.get('properties', {}).get('periods', [])
    def period(x):
        return _compact({k: x.get(k) for k in ('name','startTime','endTime','isDaytime','temperature','temperatureUnit','windSpeed','windDirection','probabilityOfPrecipitation','relativeHumidity','dewpoint','shortForecast','detailedForecast')})
    out = {
        'point': _compact({k: p.get(k) for k in ('gridId','gridX','gridY','forecastOffice','timeZone','radarStation')}),
        'forecast_periods': [period(x) for x in periods[:7]],
        'hourly_periods_next_24h': [period(x) for x in hperiods[:24]],
        'sources': [src(u, 'NWS point'), *([src(p['forecast'], 'NWS forecast')] if p.get('forecast') else []), *([src(p['forecastHourly'], 'NWS hourly')] if p.get('forecastHourly') else [])]
    }
    record_sources(out['sources'])
    return out


def nws_alerts(latitude: float | None = None, longitude: float | None = None, area: str | None = None):
    """Get active NWS alerts by U.S. point or two-letter state, returned as compact structured alert records."""
    p = {'point': f'{latitude:.4f},{longitude:.4f}'} if latitude is not None and longitude is not None else {'area': area.upper() if area else ''}
    u = f'{NWS}/alerts'
    r = get(u, p)
    features = r.json().get('features', [])
    alerts = []
    for f in features[:30]:
        x = f.get('properties', {})
        alerts.append(_compact({k: x.get(k) for k in ('id','sent','effective','onset','expires','ends','status','messageType','event','headline','severity','certainty','urgency','areaDesc','senderName','description','instruction')}))
    out = {'alerts': alerts, 'count': len(alerts), 'sources': [src(r.url, 'NWS active alerts')]}
    record_sources(out['sources'])
    return out


def nws_observations(latitude: float, longitude: float):
    """Get recent nearby NWS surface observations with temperature, dew point, pressure, wind, visibility, and cloud fields."""
    u = f'{NWS}/points/{latitude:.4f},{longitude:.4f}'
    p = get(u).json()['properties']
    su = p['observationStations']
    stations = get(su).json().get('features', [])
    obs = []
    for s in stations[:6]:
        st = s['properties']['stationIdentifier']
        ou = f'{NWS}/stations/{st}/observations/latest'
        try:
            q = get(ou).json().get('properties', {})
            obs.append(_compact({
                'station': st, 'timestamp': q.get('timestamp'), 'textDescription': q.get('textDescription'),
                'temperature': q.get('temperature'), 'dewpoint': q.get('dewpoint'), 'relativeHumidity': q.get('relativeHumidity'),
                'windDirection': q.get('windDirection'), 'windSpeed': q.get('windSpeed'), 'windGust': q.get('windGust'),
                'barometricPressure': q.get('barometricPressure'), 'visibility': q.get('visibility'),
                'seaLevelPressure': q.get('seaLevelPressure'), 'windChill': q.get('windChill'), 'heatIndex': q.get('heatIndex'),
                'cloudLayers': q.get('cloudLayers'), 'presentWeather': q.get('presentWeather'),
                'stationName': q.get('stationName'), 'elevation': q.get('elevation')
            }))
        except requests.RequestException:
            continue
    out = {'observations': obs, 'sources': [src(su, 'NWS observation stations')]}
    record_sources(out['sources'])
    return out


def ncei_search(keyword: str):
    """Search public NOAA NCEI datasets by keyword; intended for historical/climate data rather than real-time NWP."""
    u = 'https://www.ncei.noaa.gov/access/services/search/v1/datasets'
    r = get(u, {'search': keyword, 'limit': 20})
    out = {'results': r.json(), 'sources': [src(r.url, 'NOAA NCEI dataset search')]}
    record_sources(out['sources'])
    return out


def ncei_data(dataset: str, start_date: str, end_date: str, stations: str | None = None, datatype: str | None = None, units: str = 'standard', limit: int = 1000):
    """Query NOAA NCEI Access Data Service for historical/climate data over a date range."""
    p = {'dataset': dataset, 'startDate': start_date, 'endDate': end_date, 'format': 'json', 'units': units, 'limit': str(limit)}
    if stations: p['stations'] = stations
    if datatype: p['datatype'] = datatype
    r = get(NCEI, p)
    try: data = r.json()
    except ValueError: data = r.text
    out = {'data': data, 'sources': [src(r.url, 'NOAA NCEI data query')]}
    record_sources(out['sources'])
    return out


def spc_outlook():
    """Fetch and parse the current NOAA SPC convective outlook page into compact categorical/text records."""
    u = 'https://www.spc.noaa.gov/products/outlook/'
    r = get(u, headers={'Accept': 'text/html'})
    text = re.sub(r'\s+', ' ', r.text)
    events = []
    # Capture common SPC categorical risk labels from page text without pretending to parse every graphic polygon.
    for label in ('High Risk', 'Moderate Risk', 'Enhanced Risk', 'Slight Risk', 'Marginal Risk', 'TSTM Risk', 'No Risk'):
        if label.lower() in text.lower():
            events.append(label)
    out = {'product': 'SPC Convective Outlook', 'risk_labels_detected': list(dict.fromkeys(events)), 'page_excerpt': text[:12000], 'note': 'Graphical boundaries are not fully decoded into GIS polygons by this tool.', 'sources': [src(u, 'NOAA SPC outlook products')]}
    record_sources(out['sources'])
    return out


def nexrad_radar(radar_site: str, product_index: int = 0):
    """Return NWS RIDGE radar image URL plus machine-readable site/product metadata; image decoding remains provider-dependent."""
    site = radar_site.strip().upper()
    if len(site) != 4 or not site.isalnum():
        raise ValueError('Use a four-character NEXRAD site such as KBOX.')
    i = max(0, min(9, int(product_index)))
    u = f'https://radar.weather.gov/ridge/standard/{site}_{i}.gif'
    r = get(u, headers={'Accept': 'image/gif'})
    out = {'radar_site': site, 'product_index': i, 'image_url': u, 'bytes': len(r.content), 'note': 'The application can download this image and delegate pixel analysis to the local Qwen3-VL vision specialist.', 'sources': [src(u, f'NWS RIDGE radar {site}')]}
    record_sources(out['sources'])
    return out


def goes19():
    """Return current NOAA GOES-19 full-disk GeoColor page metadata; image inspection remains provider-dependent."""
    u = 'https://www.goes.noaa.gov/fulldisk_band.php?band=GEOCOLOR&length=12&sat=G19'
    r = get(u, headers={'Accept': 'text/html'})
    text = re.sub(r'\s+', ' ', r.text)
    out = {'page_url': u, 'product': 'GOES-19 Full Disk GeoColor', 'page_excerpt': text[:12000], 'sources': [src(u, 'NOAA GOES-19 Full Disk GeoColor')]}
    record_sources(out['sources'])
    return out


def _iso_now():
    return datetime.now(timezone.utc)


def _candidate_cycles(now, model):
    # Keep retries bounded so an unavailable model cycle cannot stall the whole analysis.
    if model == 'gfs':
        seen = set()
        for hours_back in range(0, 25):
            t = now - timedelta(hours=hours_back)
            if t.hour in (0, 6, 12, 18) and t.replace(minute=0, second=0, microsecond=0) not in seen:
                seen.add(t.replace(minute=0, second=0, microsecond=0))
                yield t.replace(minute=0, second=0, microsecond=0)
    else:
        for hours_back in range(0, 7):
            t = now - timedelta(hours=hours_back)
            yield t.replace(minute=0, second=0, microsecond=0)


def _nomads_grib_url(model: str, cycle: datetime, forecast_hour: int, lat: float, lon: float, variables, levels):
    date = cycle.strftime('%Y%m%d')
    hh = cycle.strftime('%H')
    if model.lower() == 'hrrr':
        endpoint = f'{NOMADS}/filter_hrrr_2d.pl'
        directory = f'/hrrr.{date}/conus'
        file = f'hrrr.t{hh}z.wrfsfcf{forecast_hour:02d}.grib2'
        params = {'dir': directory, 'file': file, 'subregion': '', 'leftlon': f'{lon-0.25:.3f}', 'rightlon': f'{lon+0.25:.3f}', 'toplat': f'{lat+0.25:.3f}', 'bottomlat': f'{lat-0.25:.3f}'}
        for v in variables: params[f'var_{v.upper()}'] = 'on'
        for lev in levels: params[f'lev_{lev}'] = 'on'
    elif model.lower() == 'gfs':
        if cycle.hour not in (0, 6, 12, 18):
            raise ValueError('GFS cycle must be 00, 06, 12, or 18 UTC.')
        endpoint = f'{NOMADS}/filter_gfs_0p25.pl'
        directory = f'/gfs.{date}/{hh}/atmos'
        file = f'gfs.t{hh}z.pgrb2.0p25.f{forecast_hour:03d}'
        params = {'dir': directory, 'file': file, 'subregion': '', 'leftlon': f'{lon-0.5:.3f}', 'rightlon': f'{lon+0.5:.3f}', 'toplat': f'{lat+0.5:.3f}', 'bottomlat': f'{lat-0.5:.3f}'}
        for v in variables: params[f'var_{v.upper()}'] = 'on'
        for lev in levels: params[f'lev_{lev}'] = 'on'
    else:
        raise ValueError('Model must be HRRR or GFS.')
    return endpoint, params, f'{endpoint}?{urlencode(params)}'


def _parse_grib_nearest(path: Path, latitude: float, longitude: float):
    try:
        import xarray as xr, cfgrib, numpy as np
    except Exception as e: return {'parse_error': f'xarray/cfgrib unavailable: {e}', 'grib_file': str(path)}
    def spatial_slice(ds):
        latn='latitude' if 'latitude' in ds.coords else ('lat' if 'lat' in ds.coords else None); lonn='longitude' if 'longitude' in ds.coords else ('lon' if 'lon' in ds.coords else None)
        if not latn or not lonn:return None
        la,lo=ds[latn],ds[lonn]; target=longitude%360 if float(lo.max())>180 else longitude
        if la.ndim==2 and lo.ndim==2:
            dist=(la-latitude)**2+(((lo-target+180)%360)-180)**2; ij=np.unravel_index(int(np.nanargmin(dist.values)),dist.shape)
            y,x=ij; arrs={name:(da.isel({da.dims[-2]:y,da.dims[-1]:x}) if da.ndim>=2 and latn in da.dims and lonn in da.dims else da) for name,da in ds.data_vars.items()}
            return arrs,{'latitude':float(la.values[ij]),'longitude':float(lo.values[ij])}
        pt=ds.sel({latn:latitude,lonn:target},method='nearest'); return {n:da for n,da in pt.data_vars.items()},{'latitude':float(pt[latn].values),'longitude':float(pt[lonn].values)}
    def meta_for(da):
        a=da.attrs or {}; e=da.encoding or {}; m={}
        for k in ('GRIB_typeOfLevel','GRIB_level','GRIB_typeOfFirstFixedSurface','GRIB_scaledValueOfFirstFixedSurface','GRIB_typeOfSecondFixedSurface','GRIB_scaledValueOfSecondFixedSurface'):
            if k in a:m[k]=a[k]
            elif k in e:m[k]=e[k]
        for k in ('heightAboveGround','heightAboveGroundLayer','level'):
            if k in da.coords:
                try:m[k]=da.coords[k].values.tolist()
                except Exception:pass
        return m
    try:groups=cfgrib.open_datasets(path,backend_kwargs={'indexpath':''})
    except Exception as e:return {'parse_error':f'GRIB parsing failed: {e}','grib_file':str(path)}
    records=[]; nearest=None
    try:
        for gi,ds in enumerate(groups):
            picked=spatial_slice(ds)
            if not picked:continue
            arrs,near=picked;nearest=near
            for name,da in arrs.items():
                # Expand every non-singleton coordinate so layer records cannot collapse into one scalar.
                work=da
                dims=[d for d in work.dims if work.sizes.get(d,1)>1]
                coords=[list(range(work.sizes[d])) for d in dims]
                import itertools
                combos=list(itertools.product(*coords)) if dims else [()]
                if len(combos)>64: combos=combos[:64]
                for combo in combos:
                    cur=work
                    coordvals={}
                    for d,i in zip(dims,combo):
                        try:coordvals[d]=work[d].values[i].item()
                        except Exception:coordvals[d]=str(work[d].values[i])
                        cur=cur.isel({d:i})
                    try:
                        if getattr(cur.values,'size',1)!=1:continue
                        val=float(cur.values.item())
                        if not np.isfinite(val):continue
                    except Exception:continue
                    m=meta_for(da);m.update(coordvals)
                    label=''
                    # Prefer authoritative GRIB fixed-surface bounds. cfgrib may expose a
                    # misleading singleton heightAboveGroundLayer coordinate for these records.
                    top=None; bottom=None
                    try:
                        b0=m.get('GRIB_scaledValueOfFirstFixedSurface')
                        b1=m.get('GRIB_scaledValueOfSecondFixedSurface')
                        if isinstance(b0,(int,float)) and isinstance(b1,(int,float)) and float(b0)!=float(b1):
                            bottom,top=sorted((float(b0),float(b1)))
                        elif isinstance(b0,(int,float)) and isinstance(b1,(int,float)) and float(b0)==0.0:
                            bottom,top=0.0,float(b1)
                    except Exception:
                        pass
                    if bottom is None and top is None and isinstance(coordvals.get('heightAboveGroundLayer'),(int,float)):
                        top=float(coordvals['heightAboveGroundLayer']); bottom=0.0
                    if top is not None and bottom is not None and abs(top-round(top))<1e-6 and abs(bottom)<1e-6:
                        top_i=int(round(top)); label=f'0-{top_i} m AGL'
                    rec={'record_id':f'g{gi}:{name}:{len(records)}','name':name,'value':val,'units':cur.attrs.get('units',da.attrs.get('units','')),'layer_metadata':m,'layer_label':label,'source_field':name,'bottom_level':bottom,'top_level':top}
                    records.append(rec)
            try:ds.close()
            except Exception:pass
    finally:pass
    fields={};dups={}
    for r in records:
        fields[r['name']]=r['value'];dups[r['name']]=dups.get(r['name'],0)+1
    dups={k:v for k,v in dups.items() if v>1}
    return {'nearest_point':nearest,'fields':fields,'records':records,'record_count':len(records),'duplicate_field_names':dups,'records_preserve_grib_layer_metadata':True}


def _quantitative(records):
    def safe_units(value, source_unit, target_unit):
        try: return compatible_unit(float(value), str(source_unit or target_unit).replace('**','^'), target_unit)
        except Exception: return None
    def find(name, label):
        vals=[r for r in records if r.get('name')==name and r.get('layer_label')==label]
        return vals[0] if len(vals)==1 else (None if len(vals)==0 else {'ambiguous':len(vals)})
    out={}
    for name,key,units in [('cape','surface_cape','J kg-1'),('cin','surface_cin','J kg-1')]:
        vals=[r for r in records if r.get('name')==name and (r.get('layer_label') in ('','surface') or r.get('layer_label') is None)]
        if vals:
            uval=safe_units(vals[0]['value'], vals[0].get('units',units), units)
            out[key]={'value':vals[0]['value'] if uval is None else uval,'units':vals[0].get('units',units),'source_record':vals[0]['record_id'],'status':'model_field'}
    a=find('hlcy','0-1000 m AGL'); b=find('hlcy','0-3000 m AGL')
    out['srh_0_1km']={'value':a['value'] if safe_units(a['value'],a.get('units','m2 s-2'),'m2 s-2') is None else safe_units(a['value'],a.get('units','m2 s-2'),'m2 s-2'),'units':a.get('units','m2 s-2'),'source_record':a['record_id'],'layer':'0-1000 m AGL','status':'model_field'} if a and 'value' in a else {'status':'unavailable','reason':'no uniquely identified 0-1000 m HLCY record with explicit matching layer metadata'}
    out['srh_0_3km']={'value':b['value'] if safe_units(b['value'],b.get('units','m2 s-2'),'m2 s-2') is None else safe_units(b['value'],b.get('units','m2 s-2'),'m2 s-2'),'units':b.get('units','m2 s-2'),'source_record':b['record_id'],'layer':'0-3000 m AGL','status':'model_field'} if b and 'value' in b else {'status':'unavailable','reason':'no uniquely identified 0-3000 m HLCY record with explicit matching layer metadata'}
    unresolved=[r for r in records if r.get('name') in ('hlcy','vucsh','vvcsh') and not r.get('layer_label')]
    if unresolved:
        out['unresolved_layer_fields']=[{'source_record':r.get('record_id'),'field':r.get('name'),'value':r.get('value'),'units':r.get('units',''),'status':'ambiguous_layer_identity'} for r in unresolved]
    # VUCSH/VVCSH are vertical shear RATE components [1/s], not bulk-shear vectors [m/s].
    # Report their layer-specific rate only; do not relabel that quantity as bulk shear.
    for top in (1000,6000):
        label=f'0-{top} m AGL';u=find('vucsh',label);v=find('vvcsh',label);key=f'vertical_shear_rate_0_{top//1000}km'
        if u and v and 'value' in u and 'value' in v and u.get('units')==v.get('units')=='s-1':
            mag=math.hypot(float(u['value']),float(v['value']))
            out[key]={'value':mag,'units':'s-1','source_fields':[u['record_id'],v['record_id']],'layer':label,'status':'derived_from_model_shear_rate_components','note':'This is a shear-rate magnitude, not bulk shear.'}
        else:out[key]={'status':'unavailable','reason':f'missing uniquely identified VUCSH/VVCSH pair for {label}'}
    out['bulk_shear_0_1km']={'status':'unavailable','reason':'requires actual wind-vector difference across 0-1 km; HRRR VUCSH/VVCSH shear-rate fields are not relabeled as bulk shear'}
    out['bulk_shear_0_3km']={'status':'unavailable','reason':'requires an actual model wind profile spanning 0-3 km AGL'}
    out['bulk_shear_0_6km']={'status':'unavailable','reason':'requires an actual model wind profile spanning 0-6 km AGL'}
    return out

def nwp_model_guidance(model: str, latitude: float, longitude: float, forecast_hour: int = 0, include_upper_air: bool = True):
    """Fetch NOAA/NCEP HRRR or GFS model guidance near a point and parse selected fields. Never invents unavailable fields."""
    model = model.lower().strip()
    if model not in ('hrrr', 'gfs'):
        raise ValueError('model must be HRRR or GFS')
    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        raise ValueError('Invalid latitude/longitude.')
    forecast_hour = max(0, min(120 if model == 'gfs' else 48, int(forecast_hour)))
    now = _iso_now()
    if model == 'hrrr':
        variables = ['CAPE','CIN','HLCY','UGRD','VGRD','VUCSH','VVCSH','HGT']
        levels = ['surface','2_m_above_ground','10_m_above_ground','1000_m_above_ground','1000-0_m_above_ground','3000-0_m_above_ground','0-1000_m_above_ground','0-6000_m_above_ground']
    else:
        variables = ['TMP','DPT','UGRD','VGRD','RH','CAPE','CIN','PWAT','GUST']
        levels = ['surface','2_m_above_ground','10_m_above_ground','850_mb','700_mb','500_mb'] if include_upper_air else ['surface','2_m_above_ground','10_m_above_ground']
    # Save only a small filtered GRIB in the app temp directory.
    base = Path(os.environ.get('APPDATA', str(Path.home()))) / 'MeteorologyAI' / 'temp_attachments' / 'model_cache'
    base.mkdir(parents=True, exist_ok=True)
    tried = []
    last_error = None
    max_candidates = 3 if model == 'hrrr' else 4
    for attempt, t in enumerate(_candidate_cycles(now, model)):
        if attempt >= max_candidates:
            break
        if model == 'gfs' and t.hour not in (0, 6, 12, 18):
            continue
        endpoint, params, full_url = _nomads_grib_url(model, t, forecast_hour, latitude, longitude, variables, levels)
        tried.append(full_url)
        try:
            r = requests.get(endpoint, params=params, headers={'User-Agent': UA, 'Accept': 'application/octet-stream'}, timeout=12)
            if r.status_code != 200 or not r.content or r.content[:4] not in (b'GRIB',):
                last_error = f'HTTP {r.status_code}: {r.text[:300] if r.text else "empty response"}'
                continue
            stamp = f'{model}_{t.strftime("%Y%m%dT%HZ")}_f{forecast_hour:03d}_{latitude:.3f}_{longitude:.3f}'.replace('-', 'm')
            path = base / f'{stamp}.grib2'
            path.write_bytes(r.content)
            parsed = _parse_grib_nearest(path, latitude, longitude)
            valid = t + timedelta(hours=forecast_hour)
            if 'parse_error' in parsed: last_error=parsed['parse_error']; continue
            parsed['quantitative_parameters']=_quantitative(parsed.get('records',[]))
            out = {
                'model': model.upper(), 'cycle_time_utc': t.isoformat(), 'forecast_hour': forecast_hour,
                'valid_time_utc': valid.isoformat(), 'request_point': {'latitude': latitude, 'longitude': longitude},
                'fields_requested': variables, 'levels_requested': levels, 'data': parsed,
                'quantitative_parameters': parsed['quantitative_parameters'],
                'diagnostics': {'record_count':parsed.get('record_count',0),'duplicate_field_names':parsed.get('duplicate_field_names',{}),'records_preserve_grib_layer_metadata':True,'retrieval_http_status':r.status_code,'request_url':full_url},
                'note': 'Only fields returned and successfully parsed are included. Missing parameters are unavailable, not estimated. Distinct GRIB records are preserved with layer metadata.',
                'field_use_rule': 'For layer-dependent parameters, use only quantitative_parameters or records with explicit matching layer metadata. Scalar data.fields entries do not establish layer identity.',
                'sources': [src(full_url, f'NOAA NCEP NOMADS {model.upper()} model guidance')]
            }
            record_sources(out['sources'])
            return out
        except (requests.RequestException, OSError) as e:
            last_error = str(e)
            continue
    raise RuntimeError(f'No usable {model.upper()} model guidance was retrieved from NOAA/NOMADS. Last error: {last_error or "unknown"}. Attempted URLs: {tried}')

def meteorological_analysis_bundle(latitude: float, longitude: float, forecast_hour: int = 0):
    """Build a consolidated official-data weather-analysis bundle: NWS observations/forecast/alerts, SPC outlook, HRRR, and GFS guidance. Failed components are reported as unavailable."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    jobs = {
        'nws': lambda: nws_point_weather(latitude, longitude),
        'alerts': lambda: nws_alerts(latitude=latitude, longitude=longitude),
        'observations': lambda: nws_observations(latitude, longitude),
        'spc': spc_outlook,
        'hrrr': lambda: nwp_model_guidance('hrrr', latitude, longitude, forecast_hour, True),
        'gfs': lambda: nwp_model_guidance('gfs', latitude, longitude, forecast_hour, True),
    }
    out = {'request': {'latitude': latitude, 'longitude': longitude, 'forecast_hour': forecast_hour}, 'components': {}, 'sources': [], 'notes': []}
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = {pool.submit(fn): name for name, fn in jobs.items()}
        for fut in as_completed(futures):
            name = futures[fut]
            try:
                result = fut.result()
                out['components'][name] = result
                if isinstance(result, dict):
                    out['sources'].extend(result.get('sources', []))
            except Exception as e:
                out['components'][name] = {'unavailable': str(e)}
                out['notes'].append(f'{name}: unavailable ({e})')
    seen = set(); sources = []
    for item in out['sources']:
        u = item.get('url') if isinstance(item, dict) else None
        if u and u not in seen:
            seen.add(u); sources.append(item)
    out['sources'] = sources
    record_sources(sources)
    return out


def fetch_url(url: str):
    """Fetch a public HTTP/HTTPS URL explicitly requested by the user for inspection."""
    if not url.startswith(('https://', 'http://')):
        raise ValueError('Only HTTP/HTTPS URLs are allowed.')
    r = get(url, headers={'Accept': 'text/html,application/json'})
    out = {'url': url, 'content_type': r.headers.get('content-type', ''), 'content_excerpt': r.text[:40000], 'sources': [src(url, 'Fetched public URL')]}
    record_sources(out['sources'])
    return out


TOOLS = [nws_point_weather, nws_alerts, nws_observations, ncei_search, ncei_data, spc_outlook, nexrad_radar, goes19, nwp_model_guidance, meteorological_analysis_bundle, fetch_url]
