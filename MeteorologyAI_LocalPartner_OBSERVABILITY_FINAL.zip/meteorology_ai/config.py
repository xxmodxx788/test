from __future__ import annotations
import copy, json, os
from pathlib import Path

APP_DIR = Path(os.environ.get('APPDATA', str(Path.home()))) / 'MeteorologyAI'
CONV_DIR = APP_DIR / 'conversations'
WS_DIR = APP_DIR / 'workspaces'
LIB_DIR = APP_DIR / 'library'
GEN_DIR = APP_DIR / 'generated_images'
TMP_DIR = APP_DIR / 'temp_attachments'
LOCAL_MODELS_DIR = APP_DIR / 'local_models'
APP_ROOT = Path(__file__).resolve().parents[1]
LOG_DIR = APP_ROOT / 'logs'
CONFIG = APP_DIR / 'config.json'

DEFAULT_PROMPT = '''You are Meteorology AI, a technically rigorous local meteorology research assistant.

PRIMARY ROLE: GPT-OSS is the main conversational model, orchestrator, researcher, calculator, tool user, and final synthesizer.
VISION PARTNER: Qwen3-VL 4B is a local vision specialist. When an image must be inspected, delegate it through the application's vision tools. Never claim to see pixels unless a successful vision result is present.
PARTNERSHIP: Both models use the application's shared evidence and workflow ledger. Preserve source identity, timestamps, image IDs, model cycles, valid times, and provenance. Qwen findings are visual evidence/advice; GPT-OSS remains the final decision-maker.

DATA INTEGRITY: Never invent observations, source data, tool results, image findings, or quantitative values. Never estimate CAPE, CIN, shear, helicity, SRH, lapse rates, sounding values, radar-derived quantities, or other meteorological parameters from generic/typical values or insufficient inputs. Missing inputs mean unavailable. Distinguish observed data, model fields, application-derived calculations, visual interpretation, and inference.

RESEARCH MODES: Normal, Web Research, Deep Research, Trusted Government. In Web Research, web_search and authoritative weather tools may be used. In Trusted Government, prefer direct government sources and do not use broad web search unless explicitly needed for an official source. Trusted Government prefers direct NOAA/NWS/NCEI/NESDIS/SPC/NCEP/NOMADS sources exposed by the application.

EFFICIENCY: Avoid duplicate tool calls. Use bounded, relevant context. Do not repeatedly retry an identical failed tool call. If a tool fails, classify it as recoverable or terminal and continue only when an alternate path is sensible.'''

DEFAULTS = {
    'system_prompt': DEFAULT_PROMPT,
    'advanced_system_instructions': '', 'global_instructions': '',
    'research_mode': 'normal', 'thinking': 'medium', 'temperature': 0.7,
    'max_output_tokens': 8192, 'tool_loop_max': 12,
    'primary': {'model': '', 'server_path': '', 'port': 8080, 'base_url': 'http://127.0.0.1:8080/v1',
                'context': 32768, 'gpu_layers': -1, 'threads': 0, 'threads_batch': 0,
                'batch_size': 2048, 'ubatch_size': 512, 'flash_attn': 'auto', 'continuous_batching': False},
    'vision': {'model': '', 'mmproj': '', 'server_path': '', 'port': 8081, 'base_url': 'http://127.0.0.1:8081/v1',
               'context': 8192, 'gpu_layers': -1, 'threads': 0, 'threads_batch': 0,
               'batch_size': 1024, 'ubatch_size': 256, 'flash_attn': 'auto', 'continuous_batching': True,
               'keep_loaded': True, 'auto_cpu_fallback': True},
}

def _merge(a,b):
    out=copy.deepcopy(a)
    for k,v in (b or {}).items():
        if isinstance(v,dict) and isinstance(out.get(k),dict): out[k]=_merge(out[k],v)
        else: out[k]=v
    return out

def init_dirs():
    for p in (APP_DIR,CONV_DIR,WS_DIR,LIB_DIR,GEN_DIR,TMP_DIR,LOCAL_MODELS_DIR,LOG_DIR): p.mkdir(parents=True,exist_ok=True)

def load():
    init_dirs()
    try: raw=json.loads(CONFIG.read_text(encoding='utf-8'))
    except Exception: raw={}
    # migrate only the useful old local-model settings
    old_local=((raw.get('providers') or {}).get('local') or {})
    out=_merge(DEFAULTS,raw)
    for k in ('model','server_path','context','gpu_layers','threads','threads_batch','batch_size','ubatch_size','flash_attn','continuous_batching'):
        if old_local.get(k) not in (None,''): out['primary'][k]=old_local[k]
    out['primary']['port']=8080; out['primary']['base_url']='http://127.0.0.1:8080/v1'
    config_changed = False
    # Primary GPT-OSS needs enough headroom for the intentionally large system prompt plus
    # tool schemas, meteorological evidence, conversation history, and a useful completion.
    # Upgrade legacy 24K-or-smaller defaults to the supported 32K baseline, while preventing
    # accidental values above the tested application limit.
    current_ctx = int(out['primary'].get('context',32768))
    if current_ctx < 32768:
        out['primary']['context']=32768
        config_changed = True
    elif current_ctx > 32768:
        out['primary']['context']=32768
        config_changed = True
    if out['primary'].get('continuous_batching',False):
        out['primary']['continuous_batching']=False
        config_changed = True
    out['vision']['port']=8081; out['vision']['base_url']='http://127.0.0.1:8081/v1'
    # Recover the known llama.cpp installation used by prior Meteorology AI builds
    # when an older/new configuration has an empty server_path.
    if not out['primary'].get('server_path'):
        candidates=[
            Path(r'C:\AI\llama.cpp\llama-server.exe'),
            Path(r'C:\llama.cpp\llama-server.exe'),
            APP_DIR/'runtime'/'llama-server.exe',
            APP_DIR/'llama.cpp'/'llama-server.exe',
            APP_DIR.parent/'llama.cpp'/'llama-server.exe',
        ]
        found=next((str(x) for x in candidates if x.is_file()), '')
        if found:
            out['primary']['server_path']=found
    if not out['vision'].get('server_path'):
        out['vision']['server_path']=out['primary'].get('server_path','')
    for k in ('providers','provider','api_key','fallback_enabled','fallback_order'): out.pop(k,None)
    # Repair configs that accidentally store the local_models directory instead of a GGUF file.
    # Recovery discovery happens once at config-load time; the repaired absolute file path is
    # saved back into the user config so normal startup remains fast afterwards.
    for role in ('primary','vision'):
        current = str(out[role].get('model','') or '')
        resolved_model = resolve_model_path(current, role, allow_discovery=True)
        if resolved_model.is_file() and str(resolved_model) != current:
            out[role]['model'] = str(resolved_model)
            config_changed = True
    if out['vision'].get('model'):
        mm = Path(str(out['vision'].get('mmproj',''))).expanduser()
        if mm.is_dir():
            hits = sorted(mm.glob('mmproj-*.gguf'))
            if hits:
                out['vision']['mmproj'] = str(hits[0])
                config_changed = True
    if config_changed:
        try:
            save(out)
        except Exception:
            pass
    return out

def resolve_model_path(value, role='primary', allow_discovery=True):
    """Resolve a model path without scanning the model tree during normal startup.

    Exact files and known built-in model locations are checked first. Recursive discovery
    is reserved for explicit recovery/discovery cases because walking large model trees can
    noticeably delay GUI startup.
    """
    raw = str(value or '').strip()
    candidate = Path(raw).expanduser() if raw else LOCAL_MODELS_DIR
    if not candidate.is_absolute():
        candidate = LOCAL_MODELS_DIR / candidate
    candidate = candidate.resolve()
    if candidate.is_file():
        return candidate
    if not candidate.is_dir():
        return candidate

    filename = 'openai_gpt-oss-20b-MXFP4.gguf' if role == 'primary' else 'Qwen3VL-4B-Thinking-Q4_K_M.gguf'
    known_dirs = ['qwen3-vl-4b-thinking-q4', 'qwen3-vl-4b', 'Qwen3-VL-4B-Thinking-GGUF'] if role == 'vision' else ['gpt-oss-20b-mxfp4', 'gpt-oss-20b', 'openai_gpt-oss-20b-GGUF']
    for d in known_dirs:
        model_dir = candidate / d
        hit = model_dir / filename
        if hit.is_file():
            return hit
        if model_dir.is_dir():
            # Some existing installs use the correct model folder but a different GGUF filename.
            # Search only that role-specific folder, never the entire model library, on normal startup.
            ggufs = sorted(x for x in model_dir.glob('*.gguf') if 'mmproj' not in x.name.lower())
            if len(ggufs) == 1:
                return ggufs[0]
            role_hits = [x for x in ggufs if ('gpt-oss' in x.name.lower() if role == 'primary' else 'qwen' in x.name.lower())]
            if len(role_hits) == 1:
                return role_hits[0]
    hit = candidate / filename
    if hit.is_file():
        return hit
    # If the selected value is already the model root, inspect only the two built-in role folders
    # before falling back to an explicit recursive discovery. This keeps startup fast.
    if candidate.resolve() == LOCAL_MODELS_DIR.resolve():
        for d in known_dirs:
            model_dir = LOCAL_MODELS_DIR / d
            if model_dir.is_dir():
                ggufs = sorted(x for x in model_dir.glob('*.gguf') if 'mmproj' not in x.name.lower())
                role_hits = [x for x in ggufs if ('gpt-oss' in x.name.lower() if role == 'primary' else 'qwen' in x.name.lower())]
                if len(role_hits) == 1:
                    return role_hits[0]

    # Only explicit discovery paths should recurse. This is intentionally not used by the
    # normal config load when the saved model path is blank.
    if allow_discovery:
        # First, search for the exact expected built-in filename anywhere below the selected
        # model directory. This is the safest recovery path for an accidentally stored
        # local_models directory and avoids selecting the wrong GGUF when several exist.
        exact_hits = sorted(candidate.rglob(filename))
        if exact_hits:
            return exact_hits[0]
        files = sorted(candidate.rglob('*.gguf'))
        if len(files) == 1:
            return files[0]
        needle = 'qwen3' if role == 'vision' else 'gpt-oss'
        role_hits = [x for x in files if needle in x.name.lower()]
        if role_hits:
            return role_hits[0]
    return candidate

def save(cfg):
    init_dirs(); tmp=CONFIG.with_suffix('.tmp')
    tmp.write_text(json.dumps(cfg,indent=2,ensure_ascii=False),encoding='utf-8'); tmp.replace(CONFIG)
