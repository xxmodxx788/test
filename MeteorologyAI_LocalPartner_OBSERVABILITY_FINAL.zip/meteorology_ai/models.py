from __future__ import annotations
import json,shutil,subprocess
from pathlib import Path
from urllib.parse import quote
import requests
from .config import APP_DIR,LOCAL_MODELS_DIR
from .logging_utils import workflow

BUILTINS=[
{'id':'gpt-oss-20b-mxfp4','role':'primary','name':'GPT-OSS 20B — MXFP4','repo':'bartowski/openai_gpt-oss-20b-GGUF','file':'openai_gpt-oss-20b-MXFP4.gguf','size':12100000000,'description':'Primary local reasoning model.'},
{'id':'qwen3-vl-4b-thinking-q4','role':'vision','name':'Qwen3-VL 4B Thinking — Q4_K_M','repo':'Qwen/Qwen3-VL-4B-Thinking-GGUF','file':'Qwen3VL-4B-Thinking-Q4_K_M.gguf','size':2500000000,'companion':{'repo':'Qwen/Qwen3-VL-4B-Thinking-GGUF','file':'mmproj-Qwen3VL-4B-Thinking-Q8_0.gguf','size':454000000},'description':'Local multimodal vision specialist.'}]

def url(repo,file):return f'https://huggingface.co/{repo}/resolve/main/{quote(file)}?download=true'
def human(n):
 n=float(n or 0)
 for u in ('B','KB','MB','GB','TB'):
  if n<1024 or u=='TB':return f'{n:.1f} {u}'
  n/=1024

def installed():
 out=[]
 for p in LOCAL_MODELS_DIR.rglob('*.gguf'):
  m={}; mp=p.with_suffix('.json')
  try:m=json.loads(mp.read_text(encoding='utf-8')) if mp.exists() else {}
  except Exception:pass
  out.append({'path':str(p),'name':m.get('name',p.stem),**m})
 return out

def disk_free():return shutil.disk_usage(LOCAL_MODELS_DIR).free

def _download(repo,file,target,report=None,cancel=None):
 target.parent.mkdir(parents=True,exist_ok=True); part=target.with_suffix(target.suffix+'.part'); existing=part.stat().st_size if part.exists() else 0; h={'Range':f'bytes={existing}-'} if existing else {}
 with requests.get(url(repo,file),headers=h,stream=True,timeout=60) as r:
  if existing and r.status_code==200:existing=0;part.unlink(missing_ok=True)
  r.raise_for_status(); total=int(r.headers.get('Content-Length','0'))+existing;done=existing
  with part.open('ab' if existing else 'wb') as f:
   for ch in r.iter_content(1024*1024):
    if cancel and cancel.is_set():raise RuntimeError('Download cancelled.')
    if ch:f.write(ch);done+=len(ch);report and report(done,total)
 part.replace(target)

def download(spec,report=None,cancel=None):
 need=spec['size']+sum(int(spec.get('companion',{}).get(k,0)) for k in ('size',))
 if disk_free()<need+512*1024*1024:raise RuntimeError(f'Not enough storage; need about {human(need+512*1024*1024)} free.')
 d=LOCAL_MODELS_DIR/spec['id'];d.mkdir(parents=True,exist_ok=True);main=d/spec['file']
 if not main.exists():_download(spec['repo'],spec['file'],main,report,cancel)
 comp=spec.get('companion');mp=''
 if comp:
  cp=d/comp['file']
  if not cp.exists():_download(comp['repo'],comp['file'],cp,report,cancel)
  mp=str(cp)
 meta={k:spec[k] for k in ('id','role','name','repo','file','size','description') if k in spec}; meta['mmproj']=mp
 main.with_suffix('.json').write_text(json.dumps(meta,indent=2),encoding='utf-8');return str(main)

def find_server(custom=''):
 c=[]
 if custom:c.append(Path(custom))
 c.extend([APP_DIR/'runtime'/'llama-server.exe', APP_DIR/'llama.cpp'/'llama-server.exe', Path(r'C:\AI\llama.cpp\llama-server.exe'), Path(r'C:\llama.cpp\llama-server.exe'), APP_DIR.parent/'llama.cpp'/'llama-server.exe'])
 for x in ('llama-server.exe','llama-server'):
  p=shutil.which(x)
  if p:c.append(Path(p))
 return str(next((x for x in c if x.is_file()),''))

def install_runtime():
 p=find_server()
 if p:return p
 if not shutil.which('winget'):raise RuntimeError('llama-server.exe not found and winget is unavailable.')
 r=subprocess.run(['winget','install','--id','ggml.llama.cpp','-e','--accept-source-agreements','--accept-package-agreements'],capture_output=True,text=True,timeout=300)
 if r.returncode!=0:raise RuntimeError((r.stderr or r.stdout).strip())
 p=find_server()
 if not p:raise RuntimeError('llama.cpp installation completed but llama-server.exe was not found.')
 return p
