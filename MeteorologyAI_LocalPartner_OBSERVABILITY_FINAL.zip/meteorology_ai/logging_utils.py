from __future__ import annotations

import atexit
import contextvars
import hashlib
import json
import logging
import os
import queue
import re
import sys
import threading
import time
import traceback
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from logging.handlers import QueueHandler, QueueListener, RotatingFileHandler
from pathlib import Path
from typing import Any

from .backend import json_dumps
from .config import APP_DIR, LOG_DIR

LOG_DIR.mkdir(parents=True, exist_ok=True)
TRACE_DIR = LOG_DIR / "traces"
TRACE_DIR.mkdir(parents=True, exist_ok=True)

_SCHEMA_VERSION = 1
_EVENT_QUEUE: queue.Queue[dict[str, Any] | None] = queue.Queue(maxsize=10000)
_STOP = threading.Event()
_WRITER_THREAD: threading.Thread | None = None
_WRITE_LOCK = threading.RLock()
_SEQ_LOCK = threading.RLock()
_SEQ = 0
_TRACE_SEQ: dict[str, int] = {}
_TRACE_LOCK = threading.RLock()
_TRACE_CTX: contextvars.ContextVar[dict[str, str] | None] = contextvars.ContextVar("meteorology_trace", default=None)

_SECRET_KEY_RE = re.compile(r"(?i)(api[_-]?key|authorization|bearer|password|passwd|secret|credential|access[_-]?token|refresh[_-]?token)")
_BEARER_RE = re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+")


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _redact(value: Any) -> Any:
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            if _SECRET_KEY_RE.search(str(k)):
                out[str(k)] = "[REDACTED]"
            else:
                out[str(k)] = _redact(v)
        return out
    if isinstance(value, list):
        return [_redact(v) for v in value]
    if isinstance(value, tuple):
        return [_redact(v) for v in value]
    if isinstance(value, str):
        return _BEARER_RE.sub("Bearer [REDACTED]", value)
    return value


def _next_seq() -> int:
    global _SEQ
    with _SEQ_LOCK:
        _SEQ += 1
        return _SEQ


def _trace_next_seq(trace_id: str) -> int:
    with _TRACE_LOCK:
        n = _TRACE_SEQ.get(trace_id, 0) + 1
        _TRACE_SEQ[trace_id] = n
        return n


def current_trace() -> dict[str, str] | None:
    return _TRACE_CTX.get()


def start_trace(trace_id: str | None = None, conversation_id: str | None = None, name: str = "workflow") -> dict[str, str]:
    trace = {
        "trace_id": trace_id or uuid.uuid4().hex,
        "conversation_id": str(conversation_id or ""),
        "name": str(name),
        "trace_started_monotonic_ns": str(time.monotonic_ns()),
    }
    token = _TRACE_CTX.set(trace)
    trace["_context_token"] = str(id(token))
    event("trace.start", component="workflow", stage="start", outcome="STARTED", name=name)
    return trace


def set_trace_context(trace: dict[str, str]):
    return _TRACE_CTX.set(trace)


def reset_trace_context(token) -> None:
    try:
        _TRACE_CTX.reset(token)
    except Exception:
        pass

def clear_trace_context() -> None:
    _TRACE_CTX.set(None)


def finish_trace(outcome: str = "SUCCESS", error_code: str | None = None, **fields: Any) -> None:
    trace = current_trace()
    if not trace:
        return
    start_ns = int(trace.get("trace_started_monotonic_ns", time.monotonic_ns()))
    duration_ms = max(0.0, (time.monotonic_ns() - start_ns) / 1_000_000.0)
    event("trace.finish", component="workflow", stage="finish", outcome=outcome,
          duration_ms=round(duration_ms, 3), error_code=error_code, **fields)
    _write_trace_manifest(trace, outcome, duration_ms, error_code, fields)
    with _TRACE_LOCK:
        _TRACE_SEQ.pop(trace.get("trace_id", ""), None)


def event(event_type: str, *, component: str = "application", stage: str = "event",
          severity: str = "INFO", state: str = "normal", outcome: str | None = None,
          span_id: str | None = None, parent_span_id: str | None = None, detail: str = "",
          **fields: Any) -> dict[str, Any]:
    trace = current_trace() or {}
    trace_id = trace.get("trace_id", "")
    seq = _trace_next_seq(trace_id) if trace_id else 0
    obj: dict[str, Any] = {
        "schema_version": _SCHEMA_VERSION,
        "event_id": uuid.uuid4().hex,
        "sequence": _next_seq(),
        "trace_sequence": seq,
        "timestamp": now(),
        "monotonic_ns": time.monotonic_ns(),
        "event_type": str(event_type),
        "component": str(component),
        "stage": str(stage),
        "severity": str(severity),
        "state": str(state),
        "outcome": outcome,
        "trace_id": trace_id or None,
        "conversation_id": trace.get("conversation_id") or None,
        "span_id": span_id,
        "parent_span_id": parent_span_id,
        "detail": str(detail or ""),
    }
    obj.update(_redact(fields))
    _enqueue(obj)
    if str(severity).upper() in {"ERROR", "CRITICAL"}:
        _write_jsonl_direct(LOG_DIR / "events_emergency.jsonl", obj)
    return obj


@dataclass
class Span:
    name: str
    component: str
    span_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    parent_span_id: str | None = None
    started_ns: int = field(default_factory=time.monotonic_ns)
    ended: bool = False

    def end(self, outcome: str = "SUCCESS", severity: str = "INFO", state: str = "normal", detail: str = "", **fields: Any):
        if self.ended:
            return
        self.ended = True
        duration_ms = max(0.0, (time.monotonic_ns() - self.started_ns) / 1_000_000.0)
        event(self.name + ".end", component=self.component, stage="end", severity=severity,
              state=state, outcome=outcome, span_id=self.span_id, parent_span_id=self.parent_span_id,
              detail=detail, duration_ms=round(duration_ms, 3), **fields)


def span(name: str, component: str, parent_span_id: str | None = None, **fields: Any) -> Span:
    s = Span(name=name, component=component, parent_span_id=parent_span_id)
    event(name + ".start", component=component, stage="start", outcome="STARTED",
          span_id=s.span_id, parent_span_id=s.parent_span_id, **fields)
    return s


def _queue_writer() -> None:
    while not _STOP.is_set() or not _EVENT_QUEUE.empty():
        try:
            item = _EVENT_QUEUE.get(timeout=0.25)
        except queue.Empty:
            continue
        try:
            if item is None:
                continue
            line = json_dumps(item) + "\n"
            with _WRITE_LOCK:
                with (LOG_DIR / "events.jsonl").open("a", encoding="utf-8") as f:
                    f.write(line)
                if item.get("legacy_workflow"):
                    with (LOG_DIR / "workflow.jsonl").open("a", encoding="utf-8") as f:
                        f.write(line)
                if item.get("legacy_performance"):
                    with (LOG_DIR / "performance.jsonl").open("a", encoding="utf-8") as f:
                        f.write(line)
                trace_id = item.get("trace_id")
                if trace_id:
                    tp = TRACE_DIR / str(trace_id) / "timeline.jsonl"
                    tp.parent.mkdir(parents=True, exist_ok=True)
                    with tp.open("a", encoding="utf-8") as f:
                        f.write(line)
        except Exception:
            # Logging must never crash the application and must never recursively log itself.
            pass
        finally:
            _EVENT_QUEUE.task_done()


def _ensure_writer() -> None:
    global _WRITER_THREAD
    if _WRITER_THREAD and _WRITER_THREAD.is_alive():
        return
    _WRITER_THREAD = threading.Thread(target=_queue_writer, name="TelemetryWriter", daemon=True)
    _WRITER_THREAD.start()


def _enqueue(obj: dict[str, Any]) -> None:
    _ensure_writer()
    try:
        _EVENT_QUEUE.put_nowait(obj)
    except queue.Full:
        # Drop low-severity events first in spirit; Queue is FIFO, so a bounded non-fatal drop is
        # preferable to blocking model/UI threads. Critical errors are mirrored synchronously.
        if str(obj.get("severity", "INFO")).upper() in {"ERROR", "CRITICAL"}:
            _write_jsonl_direct(LOG_DIR / "events_emergency.jsonl", obj)


def _write_jsonl_direct(path: Path, obj: dict[str, Any]) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with _WRITE_LOCK:
            with path.open("a", encoding="utf-8") as f:
                f.write(json_dumps(_redact(obj)) + "\n")
    except Exception:
        pass


def _append_trace_event(obj: dict[str, Any]) -> None:
    trace_id = obj.get("trace_id")
    if not trace_id:
        return
    _write_jsonl_direct(TRACE_DIR / str(trace_id) / "timeline.jsonl", obj)


def _write_trace_manifest(trace: dict[str, str], outcome: str, duration_ms: float,
                          error_code: str | None, fields: dict[str, Any]) -> None:
    try:
        p = TRACE_DIR / trace["trace_id"]
        p.mkdir(parents=True, exist_ok=True)
        manifest = {
            "schema_version": _SCHEMA_VERSION,
            "trace_id": trace["trace_id"],
            "conversation_id": trace.get("conversation_id") or None,
            "name": trace.get("name"),
            "started_monotonic_ns": int(trace.get("trace_started_monotonic_ns", 0)),
            "finished_at": now(),
            "duration_ms": round(duration_ms, 3),
            "outcome": outcome,
            "error_code": error_code,
            "fields": _redact(fields),
        }
        (p / "manifest.json").write_text(json_dumps(manifest, pretty=True), encoding="utf-8")
    except Exception:
        pass


def _legacy_log_setup() -> tuple[logging.Logger, QueueListener]:
    logger = logging.getLogger("meteorology_ai")
    if getattr(logger, "_meteorology_configured", False):
        return logger, getattr(logger, "_meteorology_listener")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    q = queue.Queue(maxsize=5000)
    handler = QueueHandler(q)
    logger.addHandler(handler)
    file_handler = RotatingFileHandler(LOG_DIR / "meteorology_ai.log", maxBytes=8 * 1024 * 1024,
                                       backupCount=7, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(threadName)s | %(message)s"))
    listener = QueueListener(q, file_handler, respect_handler_level=True)
    listener.start()
    logger._meteorology_configured = True
    logger._meteorology_listener = listener
    return logger, listener


logger, _LOGGER_LISTENER = _legacy_log_setup()


def shutdown_logging() -> None:
    try:
        _STOP.set()
        _EVENT_QUEUE.join()
        if _WRITER_THREAD and _WRITER_THREAD.is_alive():
            _WRITER_THREAD.join(timeout=3)
        _LOGGER_LISTENER.stop()
    except Exception:
        pass


atexit.register(shutdown_logging)


def _write_jsonl(path: Path, obj: Any) -> None:
    # Compatibility helper. All normal structured events should use event().
    _write_jsonl_direct(Path(path), obj if isinstance(obj, dict) else {"value": obj})


def workflow(kind: str, stage: str, state: str = "normal", detail: str = "", **extra: Any) -> None:
    severity = "INFO"
    if state == "warning": severity = "WARNING"
    elif state == "error": severity = "ERROR"
    event_type = f"{kind}.{stage}"
    rec = event(event_type, component=_component_for_kind(kind), stage=stage, severity=severity,
                state=state, outcome=_outcome_for_state(state), detail=str(detail), legacy_workflow=True, **extra)
    logger.info("WORKFLOW %s | stage=%s | state=%s | %s", kind, stage, state, detail)


def _component_for_kind(kind: str) -> str:
    mapping = {
        "model_request": "model",
        "model_response": "model",
        "model_server": "server",
        "tool": "tool",
        "tool_args": "tool",
        "handoff": "vision",
        "context": "context",
        "reasoning": "model",
        "model_delivery": "gui",
        "conversation": "conversation",
        "cancel": "cancellation",
        "startup": "startup",
        "request": "workflow",
        "exception": "application",
    }
    return mapping.get(kind, str(kind))


def _outcome_for_state(state: str) -> str:
    return {"normal": "SUCCESS", "warning": "PARTIAL", "error": "FAILED"}.get(state, state.upper())


def performance(obj: dict[str, Any]) -> None:
    payload = {"schema_version": _SCHEMA_VERSION, "time": now(), **_redact(obj)}
    event("performance.sample", component="performance", stage="sample", severity="DEBUG", legacy_performance=True, **payload)


def exception(exc: BaseException, stage: str = "unhandled") -> None:
    tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    logger.exception("Unhandled exception")
    workflow("exception", stage, "error", str(exc), error_type=type(exc).__name__, traceback=tb[-12000:])


def install_excepthook() -> None:
    old = sys.excepthook

    def hook(t, v, tb):
        try:
            exception(v)
        finally:
            old(t, v, tb)

    sys.excepthook = hook



def write_trace_artifact(component: str, artifact_id: str, filename: str, payload: Any) -> None:
    try:
        safe_component = re.sub(r"[^A-Za-z0-9_.-]", "_", str(component))[:80]
        safe_id = re.sub(r"[^A-Za-z0-9_.-]", "_", str(artifact_id))[:120]
        trace = current_trace()
        trace_id = trace.get('trace_id') if trace else 'unscoped'
        p = TRACE_DIR / str(trace_id) / safe_component / safe_id
        p.mkdir(parents=True, exist_ok=True)
        path = p / Path(filename).name
        if isinstance(payload, (dict, list)):
            path.write_text(json_dumps(_redact(payload), pretty=True), encoding='utf-8')
        else:
            path.write_text(str(payload), encoding='utf-8')
    except Exception:
        pass

def write_tool_trace(tool_call_id: str, filename: str, payload: Any) -> None:
    write_trace_artifact('tools', tool_call_id or 'unidentified', filename, payload)

def write_model_trace(request_id: str, role: str, filename: str, payload: Any) -> None:
    """Write request-scoped diagnostic artifacts without making logging fatal."""
    try:
        safe_id = re.sub(r"[^A-Za-z0-9_.-]", "_", str(request_id))[:120]
        trace = current_trace()
        trace_id = trace.get('trace_id') if trace else None
        if trace_id:
            p = TRACE_DIR / str(trace_id) / ('vision' if role == 'vision' else 'model') / safe_id
        else:
            p = TRACE_DIR / safe_id / role
        p.mkdir(parents=True, exist_ok=True)
        path = p / Path(filename).name
        if isinstance(payload, (dict, list)):
            path.write_text(json_dumps(_redact(payload), pretty=True), encoding="utf-8")
        else:
            path.write_text(str(payload), encoding="utf-8")
    except Exception:
        pass


def write_prompt_audit(prompt: str, cfg=None, ws=None, request_id: str = "last") -> None:
    try:
        text = "" if prompt is None else str(prompt)
        raw = text.encode("utf-8")
        meta = {
            "schema_version": _SCHEMA_VERSION,
            "request_id": str(request_id),
            "characters": len(text),
            "utf8_bytes": len(raw),
            "lines": text.count("\n") + 1 if text else 0,
            "sha256": hashlib.sha256(raw).hexdigest(),
            "model": ((cfg or {}).get("primary") or {}).get("model") if isinstance(cfg, dict) else None,
            "research_mode": (cfg or {}).get("research_mode") if isinstance(cfg, dict) else None,
            "workspace": (ws or {}).get("id") if isinstance(ws, dict) else ws,
        }
        # Keep the two easy-to-find legacy audit files for compatibility.
        (LOG_DIR / "last_system_prompt.txt").write_bytes(raw)
        (LOG_DIR / "last_system_prompt_meta.json").write_text(json_dumps(meta, pretty=True), encoding="utf-8")
        write_model_trace(request_id, "primary", "system_prompt.txt", text)
        write_model_trace(request_id, "primary", "system_prompt_meta.json", meta)
        event("prompt.audit", component="model", stage="audit", outcome="RECORDED",
              request_id=str(request_id), characters=len(text), utf8_bytes=len(raw),
              sha256=meta["sha256"], model=meta.get("model"), research_mode=meta.get("research_mode"))
    except Exception:
        pass
