from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone

from .backend import append_parquet_row
from .config import LOG_DIR
from .logging_utils import performance, _write_jsonl, event


@dataclass
class TelemetryState:
    active: bool = False
    stage: str = "Idle"
    percent: int = 0
    state: str = "normal"
    started: float = 0.0
    warnings: int = 0
    errors: int = 0
    model: str = "GPT-OSS"
    round: int = 0
    events: list = field(default_factory=list)
    last_error: str = ""


class TelemetryBus:
    def __init__(self):
        self.lock = threading.RLock()
        self.state = TelemetryState()
        self.summaries = []
        self.listeners = []
        self._last_start = 0.0

    def subscribe(self, fn):
        with self.lock:
            if fn not in self.listeners:
                self.listeners.append(fn)

    def unsubscribe(self, fn):
        with self.lock:
            try:
                self.listeners.remove(fn)
            except ValueError:
                pass

    def _emit(self):
        snap = self.snapshot()
        for fn in list(self.listeners):
            try:
                fn(snap)
            except Exception:
                pass

    def reset_idle(self, stage="Ready", percent=0, state="normal", detail="", warning=False, error=False):
        with self.lock:
            self.state = TelemetryState(active=False, stage=str(stage), percent=max(0, min(100, int(percent))), state=state)
            if warning:
                self.state.warnings = 1
            if error:
                self.state.errors = 1
                self.state.last_error = str(detail)
            if detail:
                self.state.events = [self._event_record(stage, percent, state, detail)]
        self._emit()

    def _event_record(self, stage, percent, state, detail):
        return {"time": datetime.now(timezone.utc).isoformat(), "stage": str(stage),
                "percent": max(0, min(100, int(percent))), "state": str(state), "detail": str(detail)}

    def update_idle(self, stage, percent=0, state="normal", detail="", warning=False, error=False):
        with self.lock:
            self.state.active = False
            self.state.stage = str(stage)
            self.state.percent = max(0, min(100, int(percent)))
            self.state.state = state
            if warning:
                self.state.warnings += 1
            if error:
                self.state.errors += 1
                self.state.last_error = str(detail)
            if detail:
                self.state.events.append(self._event_record(stage, self.state.percent, state, detail))
                self.state.events = self.state.events[-100:]
        self._emit()

    def start(self, model="GPT-OSS"):
        with self.lock:
            self.state = TelemetryState(active=True, started=time.monotonic(), model=str(model))
            self._last_start = self.state.started
        event("telemetry.workflow.start", component="workflow", stage="start", outcome="STARTED", model=model)
        self._emit()

    def update(self, stage, percent=None, state="normal", detail="", warning=False, error=False):
        with self.lock:
            self.state.stage = str(stage)
            if error:
                self.state.last_error = str(detail)
            if percent is not None:
                self.state.percent = max(self.state.percent, min(97, int(percent)))
            self.state.state = state
            if warning:
                self.state.warnings += 1
            if error:
                self.state.errors += 1
            self.state.events.append(self._event_record(stage, self.state.percent, state, detail))
            self.state.events = self.state.events[-100:]
        self._emit()

    def round(self, n):
        with self.lock:
            self.state.round = int(n)
        base = 18 + min(max(0, int(n) - 1), 8) * 5
        self.update(f"Reasoning — Round {n}", base, "normal")
        event("telemetry.reasoning.round", component="model", stage="round", outcome="STARTED", round=int(n))

    def tool_start(self, name):
        cur = self.snapshot()["percent"]
        target = max(cur, min(84, cur + 4))
        self.update(f"Running {name}", target, "normal")

    def tool_complete(self, name):
        cur = self.snapshot()["percent"]
        target = max(cur, min(87, cur + 3))
        self.update(f"{name} completed", target, "normal")

    def qwen_start(self, name="vision"):
        cur = self.snapshot()["percent"]
        self.update(f"Qwen3-VL — {name}", max(cur, 78), "normal")

    def qwen_complete(self, name="vision"):
        cur = self.snapshot()["percent"]
        self.update(f"Qwen3-VL — {name} complete", max(cur, 88), "normal")

    def finish(self, success=True):
        with self.lock:
            elapsed = time.monotonic() - self.state.started if self.state.started else 0
            tools = sum(1 for e in self.state.events if str(e.get("stage", "")).startswith("Running "))
            model_events = sum(1 for e in self.state.events if e.get("stage") == "GPT-OSS")
            outcome = "SUCCESS" if success else "FAILED"
            performance({"kind": "workflow_summary", "duration_s": round(elapsed, 3),
                          "warnings": self.state.warnings, "errors": self.state.errors,
                          "tool_events": tools, "reasoning_events": model_events, "outcome": outcome})
            summary = {"completed": datetime.now(timezone.utc).isoformat(), "duration_s": round(elapsed, 3),
                       "model": self.state.model, "tool_count": tools, "warnings": self.state.warnings,
                       "errors": self.state.errors, "stage": self.state.stage, "outcome": outcome,
                       "bottleneck": "See performance.jsonl"}
            self.summaries.insert(0, summary)
            self.summaries = self.summaries[:100]
            _write_jsonl(LOG_DIR / "performance_summary.jsonl", summary)
            append_parquet_row(LOG_DIR / "performance_history.parquet", summary)
            self.state.active = False
            self.state.percent = 100 if success else self.state.percent
            self.state.state = "normal" if success else "error"
        event("telemetry.workflow.finish", component="workflow", stage="finish", outcome=outcome,
              duration_s=round(elapsed, 3), warnings=self.state.warnings, errors=self.state.errors)
        self._emit()

    def summaries_snapshot(self):
        with self.lock:
            return list(self.summaries)

    def snapshot(self):
        with self.lock:
            elapsed = time.monotonic() - self.state.started if self.state.started else 0
            return {"active": self.state.active, "stage": self.state.stage, "percent": self.state.percent,
                    "state": self.state.state, "elapsed_s": round(elapsed, 1),
                    "warnings": self.state.warnings, "errors": self.state.errors, "model": self.state.model,
                    "round": self.state.round, "last_error": self.state.last_error,
                    "events": list(self.state.events[-30:])}


TELEMETRY = TelemetryBus()
