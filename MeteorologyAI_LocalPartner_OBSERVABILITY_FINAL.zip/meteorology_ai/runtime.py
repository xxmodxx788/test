from __future__ import annotations
import os,shutil,subprocess,threading,time,hashlib
from pathlib import Path
import requests
from .config import APP_DIR,LOCAL_MODELS_DIR,LOG_DIR,resolve_model_path
from .logging_utils import workflow


def resolve(p):
    q=Path(str(p)).expanduser()
    return (LOCAL_MODELS_DIR/q).resolve() if not q.is_absolute() else q.resolve()

def find_server(custom=''):
    cand=[]
    if custom:cand.append(Path(custom))
    cand += [
        APP_DIR/'runtime'/'llama-server.exe',
        APP_DIR/'llama.cpp'/'llama-server.exe',
        Path(r'C:\AI\llama.cpp\llama-server.exe'),
        Path(r'C:\llama.cpp\llama-server.exe'),
        APP_DIR.parent/'llama.cpp'/'llama-server.exe',
    ]
    w=shutil.which('llama-server.exe') or shutil.which('llama-server')
    if w:cand.append(Path(w))
    return str(next((p for p in cand if p and p.is_file()),''))

def logical_cpus():return max(1,os.cpu_count() or 1)

_HELP_CACHE = {}

class LocalServer:
    def __init__(self, role, cfg):
        self.role=role; self.cfg=dict(cfg); self.proc=None; self.log=None; self.lock=threading.RLock(); self.signature=self._sig(); self.safe_mode=False; self.ready_at=None; self.started_at=None; self.server_instance_id=None
    def _sig(self):
        return (str(resolve_model_path(self.cfg.get('model',''), self.role, allow_discovery=False)), str(resolve(self.cfg.get('mmproj',''))) if self.cfg.get('mmproj') else '', int(self.cfg.get('port',8080)), int(self.cfg.get('context',8192)), int(self.cfg.get('gpu_layers',-1)), int(self.cfg.get('threads',0)), int(self.cfg.get('threads_batch',0)), int(self.cfg.get('batch_size',1024)), int(self.cfg.get('ubatch_size',256)), self.cfg.get('flash_attn','auto'), bool(self.cfg.get('continuous_batching',True)))
    @property
    def alive(self):return bool(self.proc and self.proc.poll() is None)

    def _help(self,exe):
        key=str(Path(exe).resolve())
        cached=_HELP_CACHE.get(key)
        if cached is not None:
            return cached
        try:
            r=subprocess.run([exe,'--help'],capture_output=True,text=True,timeout=8,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)); out=(r.stdout or '')+'\n'+(r.stderr or '')
        except Exception:
            out=''
        _HELP_CACHE[key]=out
        return out
    def command(self):
        exe=find_server(self.cfg.get('server_path','')); 
        if not exe: raise RuntimeError('llama-server.exe not found. Set its path in Settings or install llama.cpp.')
        model=resolve_model_path(self.cfg.get('model',''), self.role)
        if not model.is_file():
            raise RuntimeError(f'Model file could not be resolved: {self.cfg.get("model", "")}\nResolved path: {model}')
        h=self._help(exe); threads=int(self.cfg.get('threads',0)) or logical_cpus(); tb=int(self.cfg.get('threads_batch',0)) or logical_cpus(); port=int(self.cfg.get('port',8080)); ctx=int(self.cfg.get('context',8192)); batch=max(128,int(self.cfg.get('batch_size',1024))); ub=max(64,min(int(self.cfg.get('ubatch_size',256)),batch))
        if self.safe_mode and self.role=='primary':
            ctx=min(ctx,16384); batch=min(batch,1024); ub=min(ub,256)
        cmd=[exe,'-m',str(model),'--host','127.0.0.1','--port',str(port),'-c',str(ctx),'--jinja']
        mm=self.cfg.get('mmproj','')
        if mm:
            mp=resolve(mm)
            if not mp.is_file(): raise RuntimeError(f'Multimodal projector does not exist: {mp}')
            if '--mmproj' not in h: raise RuntimeError('This llama-server does not support --mmproj. Update llama.cpp.')
            cmd += ['--mmproj',str(mp)]
        ngl=int(self.cfg.get('gpu_layers',-1))
        if ngl>=0:cmd += ['-ngl',str(ngl)]
        elif '-ngl' in h or '--gpu-layers' in h:cmd += ['-ngl','999']
        for flag,val in [('--threads',threads),('--threads-batch',tb),('--batch-size',batch),('--ubatch-size',ub)]:
            if flag in h:cmd += [flag,str(val)]
        if '--flash-attn' in h:cmd += ['--flash-attn',self.cfg.get('flash_attn','auto')]
        if (bool(self.cfg.get('continuous_batching',True)) and not (self.safe_mode and self.role=='primary')) and '--cont-batching' in h:cmd.append('--cont-batching')
        if '--parallel' in h:cmd += ['--parallel','1']
        if '--metrics' in h:cmd.append('--metrics')
        if '--no-webui' in h:cmd.append('--no-webui')
        return cmd
    def ensure(self):
        with self.lock:
            if self.alive:return
            exe=find_server(self.cfg.get('server_path',''))
            if not exe: raise RuntimeError('llama-server.exe not found. Set its path in Settings or install llama.cpp.')
            model=resolve_model_path(self.cfg.get('model',''), self.role)
            if not model.is_file():
                raise RuntimeError(f'Model file could not be resolved: {self.cfg.get("model", "")}\nResolved path: {model}')
            cmd=self.command(); port=int(self.cfg.get('port',8080)); logp=LOG_DIR/f'local_server_{port}.log'; self.log=open(logp,'a',encoding='utf-8'); command_line=' '.join(map(str,cmd)); self.log.write('\n\n===== server start =====\n'+command_line+'\n'); self.log.flush()
            self.server_instance_id=hashlib.sha256(f'{self.role}:{time.time_ns()}:{command_line}'.encode('utf-8')).hexdigest()[:20]
            self.started_at=time.monotonic()
            workflow('model_server','start',detail=f'{self.role} port={port}',role=self.role,port=port,model=model.name,server_path=exe,model_root=str(LOCAL_MODELS_DIR),
                     server_instance_id=self.server_instance_id,command_sha256=hashlib.sha256(command_line.encode('utf-8')).hexdigest(),context=int(self.cfg.get('context',8192)))
            self.proc=subprocess.Popen(cmd,stdout=self.log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            workflow('model_server','process_started',detail=f'{self.role} pid={self.proc.pid}',role=self.role,port=port,pid=self.proc.pid,server_instance_id=self.server_instance_id)
            health_ok=False
            self.ready_at=None
            for _ in range(120):
                if self.proc.poll() is not None:
                    tail=logp.read_text(encoding='utf-8',errors='replace')[-4000:]
                    workflow('model_server','start_failed','error',f'{self.role} exited before readiness; log_tail={tail[-1500:]}',role=self.role,port=port,pid=self.proc.pid if self.proc else None,exit_code=self.proc.returncode if self.proc else None,server_instance_id=self.server_instance_id,startup_duration_ms=round((time.monotonic()-self.started_at)*1000,3) if self.started_at else None)
                    raise RuntimeError(f'{self.role} llama-server exited before becoming ready (exit code {self.proc.returncode}). See logs\\local_server_{port}.log for the full startup log.')
                for endpoint in (f'http://127.0.0.1:{port}/health', f'http://127.0.0.1:{port}/v1/models'):
                    try:
                        r=requests.get(endpoint,timeout=0.8)
                        if r.ok:
                            health_ok=True
                            self.ready_at=time.time()
                            workflow('model_server','ready',detail=f'{self.role} port={port} endpoint={endpoint.rsplit("/",1)[-1]}',role=self.role,port=port,server_instance_id=self.server_instance_id,pid=self.proc.pid if self.proc else None,startup_duration_ms=round((time.monotonic()-self.started_at)*1000,3) if self.started_at else None)
                            break
                    except requests.RequestException:
                        continue
                if health_ok:
                    return
                time.sleep(.25)
            tail=logp.read_text(encoding='utf-8',errors='replace')[-2500:]
            self.stop()
            workflow('model_server','start_timeout','error',f'{self.role} did not become HTTP-ready on port {port}; log_tail={tail[-1200:]}',role=self.role,port=port)
            raise RuntimeError(f'{self.role} llama-server started but did not become HTTP-ready on port {port} within 30 seconds. The server log is in logs/local_server_{port}.log.')
    def stop(self):
        with self.lock:
            proc=self.proc; pid=proc.pid if proc else None; before_alive=bool(proc and proc.poll() is None); requested='none'
            if before_alive:
                requested='terminate'
                try:proc.terminate(); proc.wait(timeout=6)
                except Exception:
                    requested='kill'
                    try:proc.kill(); proc.wait(timeout=3)
                    except Exception:pass
            exit_code=proc.returncode if proc else None
            workflow('model_server','stop',detail=f'{self.role}',role=self.role,port=int(self.cfg.get('port',8080)),
                     server_instance_id=self.server_instance_id,pid=pid,was_alive=before_alive,termination=requested,exit_code=exit_code)
            self.proc=None
            if self.log:
                try:self.log.flush();self.log.close()
                except Exception:pass
                self.log=None

    def enable_safe_mode(self):
        with self.lock:
            self.safe_mode=True

class ModelManager:
    def __init__(self):self.lock=threading.RLock();self.primary=None;self.vision=None
    def ensure_primary(self,cfg):
        with self.lock:
            if self.primary and self.primary.alive and self.primary._sig()==LocalServer('primary',cfg)._sig():return self.primary
            if self.primary:self.primary.stop()
            self.primary=LocalServer('primary',cfg);self.primary.ensure();return self.primary
    def ensure_vision(self,cfg):
        with self.lock:
            if self.vision and self.vision.alive and self.vision._sig()==LocalServer('vision',cfg)._sig():return self.vision
            if self.vision:self.vision.stop()
            self.vision=LocalServer('vision',cfg)
            try:self.vision.ensure()
            except Exception:
                if cfg.get('auto_cpu_fallback',True) and int(cfg.get('gpu_layers',-1))==-1:
                    self.vision.stop(); c=dict(cfg);c['gpu_layers']=0;self.vision=LocalServer('vision',c);self.vision.ensure()
                else:raise
            return self.vision
    def recover_primary_after_crash(self):
        with self.lock:
            if self.primary:
                cfg=dict(self.primary.cfg)
                self.primary.stop()
                self.primary=LocalServer('primary',cfg)
                self.primary.enable_safe_mode()
                workflow('model_server','recovery_start','warning','primary crashed during request; retrying with conservative runtime settings',role='primary',port=int(cfg.get('port',8080)),context_cap=16384,cont_batching=False,batch_cap=1024)
                self.primary.ensure()
                workflow('model_server','recovery_ready','normal','primary recovered with conservative runtime settings',role='primary',port=int(cfg.get('port',8080)))
                return self.primary
            return None

    def stop_all(self):
        with self.lock:
            if self.primary:self.primary.stop()
            if self.vision:self.vision.stop()
            self.primary=self.vision=None

MODELS=ModelManager()
