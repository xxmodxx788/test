from __future__ import annotations
from pathlib import Path
from html import escape
from datetime import datetime
import copy
import threading
import markdown as md
from PySide6.QtCore import Qt,QTimer,Signal,QThread
from PySide6.QtWidgets import QApplication,QDialog,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QPlainTextEdit,QTextEdit,QTextBrowser,QListWidget,QListWidgetItem,QComboBox,QPushButton,QProgressBar,QFormLayout,QTabWidget,QDialogButtonBox,QSpinBox,QMenu,QTableWidget,QTableWidgetItem,QMessageBox,QFileDialog
from .config import load,save,resolve_model_path
from .storage import list_conv,save_conv,delete_conv,list_ws,mem,load_json,save_attachment
from .orchestrator import run
from .performance import LivePerformance, Diagnostics, PERF
from .runtime import MODELS,resolve
from .models import BUILTINS,installed,download,human,find_server
from .telemetry import TELEMETRY
from .logging_utils import workflow

DARK = """QWidget{background:#313338;color:#f2f3f5;font-family:Segoe UI;} QMainWindow{background:#313338;} QLineEdit,QPlainTextEdit,QTextEdit,QTextBrowser,QListWidget,QComboBox,QSpinBox{background:#1e1f22;color:#f2f3f5;border:1px solid #1f2023;border-radius:6px;padding:6px;} QPushButton{background:#4e5058;color:white;border:0;border-radius:6px;padding:7px 12px;} QPushButton:hover{background:#5865f2;} QListWidget::item:selected{background:#404249;} QMenu{background:#2b2d31;color:#f2f3f5;} QMenu::item:selected{background:#5865f2;} QProgressBar{background:#1e1f22;border:0;border-radius:5px;height:10px;text-align:center;} QProgressBar::chunk{background:#54a54e;border-radius:5px;} QTabBar::tab{background:#2b2d31;padding:8px 14px;} QTabBar::tab:selected{background:#5865f2;}"""

class ServerStarter(QThread):
    ready=Signal(object)
    failed=Signal(str)
    def __init__(self,cfg):
        super().__init__();self.cfg=cfg
    def run(self):
        try:
            server=MODELS.ensure_primary(self.cfg)
            self.ready.emit(server)
        except Exception as e:
            self.failed.emit(str(e))

class Worker(QThread):
    done=Signal(object)
    failed=Signal(str)
    cancelled=Signal()
    def __init__(self,cfg,msgs,ws,mem,attachments,cancel_event,conversation_id=''):
        super().__init__();self.cfg=cfg;self.msgs=msgs;self.ws=ws;self.mem=mem;self.attachments=attachments;self.cancel_event=cancel_event;self.conversation_id=conversation_id
    def run(self):
        try:
            result=run(self.cfg,self.msgs,self.ws,self.mem,self.attachments,cancel_event=self.cancel_event,conversation_id=self.conversation_id)
            if self.cancel_event.is_set(): self.cancelled.emit()
            else: self.done.emit(result)
        except Exception as e:
            if str(e)=='__METEOROLOGY_AI_CANCELLED__' or self.cancel_event.is_set(): self.cancelled.emit()
            else:self.failed.emit(str(e))
    def cancel(self):
        self.cancel_event.set()


class NewConversationDialog(QDialog):
    """Configure a new conversation without changing global AI settings."""
    def __init__(self, cfg, current_ws=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle('New Conversation')
        self.resize(640, 540)
        root = QVBoxLayout(self)

        intro = QLabel('Create a conversation with its own name and optional per-conversation AI settings.')
        intro.setWordWrap(True)
        root.addWidget(intro)

        form = QFormLayout()
        self.name = QLineEdit('New Conversation')
        self.name.setPlaceholderText('Conversation name')
        form.addRow('Name', self.name)

        self.initial = QPlainTextEdit()
        self.initial.setPlaceholderText('Optional opening message. It will be placed in the message box so you can review or edit it before sending.')
        self.initial.setMinimumHeight(170)
        form.addRow('Opening prompt', self.initial)

        self.thinking = QComboBox()
        self.thinking.addItem('Use global setting', '')
        for value in ('auto', 'low', 'medium', 'high'):
            self.thinking.addItem(value.capitalize(), value)
        form.addRow('Thinking', self.thinking)

        self.research = QComboBox()
        self.research.addItem('Use global setting', '')
        for value, label in (('normal', 'Normal'), ('web', 'Web Research'), ('deep', 'Deep Research'), ('trusted', 'Trusted Government')):
            self.research.addItem(label, value)
        form.addRow('Research mode', self.research)
        root.addLayout(form)

        ws_label = 'Default' if not current_ws else str(current_ws)
        workspace = QLabel(f'Workspace: {ws_label}\nSelect a different workspace from the main workspace selector before creating the conversation.')
        workspace.setWordWrap(True)
        root.addWidget(workspace)

        note = QLabel('Conversation-specific Thinking and Research settings override the global defaults only for this conversation. Cancel leaves the current conversation unchanged.')
        note.setWordWrap(True)
        root.addWidget(note)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    def _accept(self):
        title = self.name.text().strip()
        if not title:
            QMessageBox.warning(self, 'Conversation name', 'Please enter a conversation name.')
            self.name.setFocus()
            return
        if len(title) > 100:
            QMessageBox.warning(self, 'Conversation name', 'Conversation names must be 100 characters or fewer.')
            self.name.setFocus()
            return
        self.accept()

    def values(self):
        return {
            'title': self.name.text().strip(),
            'initial_prompt': self.initial.toPlainText(),
            'thinking_override': self.thinking.currentData() or '',
            'research_override': self.research.currentData() or '',
        }

class Settings(QDialog):
    changed=Signal()
    def __init__(self,cfg,parent=None):
        super().__init__(parent);self.cfg=cfg;self.setWindowTitle('Meteorology AI — Settings');self.resize(900,700);tabs=QTabWidget();a=QWidget();f=QFormLayout(a)
        self.th=QComboBox();self.th.addItems(['auto','low','medium','high']);self.th.setCurrentText(cfg.get('thinking','medium'));f.addRow('Thinking',self.th)
        self.rm=QComboBox();self.rm.addItems(['normal','web','deep','trusted']);self.rm.setCurrentText(cfg.get('research_mode','normal'));f.addRow('Research mode',self.rm)
        self.mx=QSpinBox();self.mx.setRange(256,16384);self.mx.setValue(min(cfg.get('max_output_tokens',8192),16384));f.addRow('Max response tokens',self.mx)
        self.tool=QSpinBox();self.tool.setRange(4,12);self.tool.setValue(min(cfg.get('tool_loop_max',10),12));f.addRow('Max tool rounds',self.tool)
        self.prompt=QPlainTextEdit(cfg.get('system_prompt',''));f.addRow('System prompt',self.prompt);self.adv=QPlainTextEdit(cfg.get('advanced_system_instructions',''));f.addRow('Advanced instructions',self.adv);self.glob=QPlainTextEdit(cfg.get('global_instructions',''));f.addRow('Global instructions',self.glob);tabs.addTab(a,'AI')
        self.modeltab=ModelSettings(cfg);tabs.addTab(self.modeltab,'Local Models');lay=QVBoxLayout(self);lay.addWidget(tabs);b=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);b.accepted.connect(self.accept);b.rejected.connect(self.reject);lay.addWidget(b)
    def accept(self):
        server_path=self.modeltab.server_path.text().strip();self.modeltab.primary['server_path']=server_path;self.modeltab.vision['server_path']=server_path;self.cfg.update(thinking=self.th.currentText(),research_mode=self.rm.currentText(),max_output_tokens=self.mx.value(),tool_loop_max=self.tool.value(),system_prompt=self.prompt.toPlainText(),advanced_system_instructions=self.adv.toPlainText(),global_instructions=self.glob.toPlainText(),primary=self.modeltab.primary,vision=self.modeltab.vision);save(self.cfg);self.changed.emit();super().accept()

class ModelSettings(QWidget):
    def __init__(self,cfg):
        super().__init__();self.primary=dict(cfg['primary']);self.vision=dict(cfg['vision']);lay=QVBoxLayout(self);self.list=QListWidget();self.status=QLabel();lay.addWidget(self.list);lay.addWidget(self.status);btn=QPushButton('Download / install selected model');btn.clicked.connect(self.download);lay.addWidget(btn);lay.addWidget(QLabel('Shared llama-server.exe path (optional)'));self.server_path=QLineEdit(self.primary.get('server_path','') or find_server(''));lay.addWidget(self.server_path);self.server_status=QLabel();lay.addWidget(self.server_status);self.server_path.textChanged.connect(self._refresh_server_status);self._refresh_server_status();self.refresh()
    def _refresh_server_status(self):
        resolved=find_server(self.server_path.text().strip())
        self.server_status.setText(f'Resolved llama-server.exe: {resolved or "NOT FOUND"}')

    def refresh(self):
        self.list.clear()
        for s in BUILTINS:
            state='installed' if any(x.get('id')==s['id'] for x in installed()) else 'not installed';self.list.addItem(f"{s['name']} — {human(s['size'])} — {state}")
    def download(self):
        i=self.list.currentRow()
        if i<0:return
        spec=BUILTINS[i]
        try:
            path=download(spec);self.status.setText(f'Installed {Path(path).name}')
            if spec['role']=='primary':self.primary['model']=path
            else:self.vision['model']=path;self.vision['mmproj']=str(Path(path).with_name(spec['companion']['file']))
            self.refresh()
        except Exception as e:QMessageBox.critical(self,'Download failed',str(e))

class Main(QMainWindow):
    telemetry_signal=Signal(object)
    def __init__(self):
        super().__init__()
        self.cfg=load();self.busy=False;self.worker=None;self.server_starter=None
        self.setWindowTitle('Meteorology AI');self.resize(1280,820);self.setStyleSheet(DARK)
        self.current_ws=None;self.workspace_mem={};self.conversation={'id':'','title':'New Conversation','messages':[],'attachments':{}};self.attachments={};self._active_prompt='';self._active_message_index=None;self._cancel_event=None;self.cancelbtn=None
        self.live=None;self.diag=None;self._build();self._load_conversations();PERF.start();TELEMETRY.reset_idle();
        if self.cfg['primary'].get('model') and resolve_model_path(self.cfg['primary']['model'], 'primary', allow_discovery=False).is_file():
            self.server_starter=ServerStarter(self.cfg['primary']);self.server_starter.ready.connect(self._primary_ready);self.server_starter.failed.connect(self._primary_failed);self.server_starter.finished.connect(self._server_starter_finished);self.server_starter.start()

    def _primary_ready(self,_server):
        workflow('startup','primary_server','normal','ready')
        TELEMETRY.update('Ready',8)

    def _primary_failed(self,error):
        workflow('startup','primary_server','warning',str(error));TELEMETRY.update_idle('Local runtime warning',8,'warning',str(error),warning=True)

    def _server_starter_finished(self):
        if self.server_starter is not None:
            self.server_starter.deleteLater()
            self.server_starter=None
    def _build(self):
        central=QWidget();h=QHBoxLayout(central);self.setCentralWidget(central);left=QVBoxLayout();right=QVBoxLayout();self.wsbox=QComboBox();self.wsbox.addItem('Default','');self.wsbox.currentIndexChanged.connect(self._workspace_changed)
        for w in list_ws():self.wsbox.addItem(w.get('name',w.get('id','Workspace')),w.get('id'))
        left.addWidget(self.wsbox);self.search=QLineEdit();self.search.setPlaceholderText('Search conversations…');self.search.textChanged.connect(self._load_conversations);self.convs=QListWidget();self.convs.setContextMenuPolicy(Qt.CustomContextMenu);self.convs.customContextMenuRequested.connect(self._conv_menu);self.convs.currentItemChanged.connect(self._select_conv);left.addWidget(self.search);left.addWidget(self.convs)
        btnrow=QHBoxLayout();
        for label,fn in [('New',self._new),('Settings',self._settings),('Attach Image',self._attach),('Performance',self._toggle_live),('Diagnostics',self._toggle_diag)]:b=QPushButton(label);b.clicked.connect(fn);btnrow.addWidget(b)
        left.addLayout(btnrow);h.addLayout(left,2);self.chat=QTextBrowser();
        # QTextBrowser normally exposes these properties, but some PySide6 builds may
        # not bind them correctly. Guard them so a GUI compatibility issue cannot
        # prevent the entire application from booting.
        if hasattr(self.chat, 'setOpenExternalLinks'):
            self.chat.setOpenExternalLinks(True)
        if hasattr(self.chat, 'setOpenLinks'):
            self.chat.setOpenLinks(True)
        self.chat.setStyleSheet('QTextEdit{background:#313338;color:#f2f3f5;border:0;}') ;self.input=QPlainTextEdit();self.input.setFixedHeight(120);send=QPushButton('Send');send.clicked.connect(self._send);right.addWidget(self.chat,1);right.addWidget(self.input);btns=QHBoxLayout();btns.addWidget(send);cancel=QPushButton('Cancel');cancel.setEnabled(False);cancel.clicked.connect(self._cancel);btns.addWidget(cancel);right.addLayout(btns);self.sendbtn=send;self.cancelbtn=cancel;h.addLayout(right,5)
        sb=self.statusBar();self.mainstatus=QLabel('Ready — Local');self.stage=QLabel('');self.progress=QProgressBar();self.progress.setFixedWidth(240);self.progress.hide();sb.addWidget(self.mainstatus);sb.addWidget(self.stage);sb.addWidget(self.progress);self.telemetry_signal.connect(self._telemetry_ui);TELEMETRY.subscribe(self.telemetry_signal.emit)
    def _toggle_live(self):
        if self.live is None:
            self.live=LivePerformance()
        if self.live.isVisible(): self.live.hide()
        else: self.live.show(); self.live.raise_(); self.live.activateWindow(); self.live.refresh()

    def _toggle_diag(self):
        if self.diag is None:
            self.diag=Diagnostics()
        if self.diag.isVisible(): self.diag.hide()
        else: self.diag.show(); self.diag.raise_(); self.diag.activateWindow(); self.diag.refresh()

    def _telemetry_ui(self,s):
        try:
            self.mainstatus.setText('Local is working…' if s['active'] else 'Ready — Local');self.stage.setText(s['stage'] if s['active'] else '');self.progress.setVisible(s['active']);self.progress.setValue(s['percent']);color='#ed4245' if s['state']=='error' else ('#faa61a' if s['warnings'] else '#54a54e');self.progress.setStyleSheet(f'QProgressBar::chunk{{background:{color};border-radius:5px;}}')
        except RuntimeError:pass
    def _conv_menu(self,pos):
        item=self.convs.itemAt(pos)
        if not item:return
        menu=QMenu(self);delete_action=menu.addAction('Delete conversation');chosen=menu.exec(self.convs.mapToGlobal(pos))
        if chosen==delete_action:
            path=item.data(Qt.UserRole)
            try:
                delete_conv(path)
                workflow('conversation','deleted',detail=str(path))
                self._reset_unsaved_conversation()
                self._load_conversations()
            except Exception as e:QMessageBox.critical(self,'Delete failed',str(e))
    def _workspace_changed(self):self.current_ws=self.wsbox.currentData() or None;self.workspace_mem=mem(self.current_ws) if self.current_ws else {};self._load_conversations()
    def _load_conversations(self):
        q=self.search.text().lower().strip();self.convs.clear()
        for c in list_conv(self.current_ws):
            if q and q not in c.get('title','').lower() and q not in c.get('id','').lower():continue
            i=QListWidgetItem(c.get('title','Conversation'));i.setData(Qt.UserRole,c.get('_path'));self.convs.addItem(i)
    def _select_conv(self,cur,prev):
        if not cur:return
        d=load_json(cur.data(Qt.UserRole),{'messages':[]});self.conversation=d;self.attachments=dict(d.get('attachments') or {});self._render()
    def _new(self):
        dlg = NewConversationDialog(self.cfg, self.current_ws, self)
        if dlg.exec() != QDialog.Accepted:
            return
        values = dlg.values()
        conv_id = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        self.conversation = {
            'id': conv_id,
            'title': values['title'],
            'messages': [],
            'attachments': {},
            'evidence': [],
            'thinking_override': values['thinking_override'],
            'research_override': values['research_override'],
        }
        self.attachments = {}
        saved_path = save_conv(self.conversation, self.current_ws)
        self.input.setPlainText(values['initial_prompt'])
        self._render()
        self._load_conversations()
        for row in range(self.convs.count()):
            item = self.convs.item(row)
            if Path(str(item.data(Qt.UserRole))).resolve() == Path(str(saved_path)).resolve():
                self.convs.setCurrentRow(row)
                break
        workflow('conversation', 'created', detail=f"title={values['title']}")
        # A non-empty opening prompt behaves exactly like the user's first sent message.
        # An empty/whitespace-only opening prompt leaves a normal blank conversation.
        initial_prompt = values['initial_prompt']
        if initial_prompt.strip():
            self.input.setPlainText(initial_prompt)
            self._send()
        else:
            self.input.clear()
    def _reset_unsaved_conversation(self):
        self.conversation={'id':'','title':'New Conversation','messages':[],'attachments':{},'evidence':[]}
        self.attachments={}
        self.input.clear()
        self._render()

    def _render_markdown(self, text):
        raw = '' if text is None else str(text)
        # Escape raw HTML first so model/user content cannot inject arbitrary GUI HTML,
        # while preserving Markdown headings, lists, tables, code fences, and line breaks.
        safe = escape(raw)
        return md.markdown(
            safe,
            extensions=['fenced_code', 'tables', 'nl2br'],
            output_format='html5',
        )

    def _render(self):
        parts=[]
        for m in self.conversation.get('messages',[]):
            role = m.get('role')
            label = 'You' if role == 'user' else 'Meteorology AI'
            body = self._render_markdown(m.get('content',''))
            parts.append(f"<div style='margin-bottom:14px'><div style='font-weight:700'>{label}</div><div style='margin-top:6px'>{body}</div></div><hr>")
        imgs=[x for x in (self.conversation.get('evidence') or []) if x.get('kind')=='image']
        if imgs:
            html=['<div style=\"font-weight:700;margin-bottom:6px\">Attached / analyzed imagery</div><table cellspacing=\"10\"><tr>']
            for x in imgs[-6:]:
                payload=x.get('payload') or {};path=payload.get('display_path') or x.get('path')
                if path:
                    uri='file:///'+str(path).replace('\\','/')
                    caption=escape(str(payload.get('url', '')), quote=True)
                    html.append(f"<td valign='top'><img src=\"{escape(uri, quote=True)}\" width='360'><br><small>{caption}</small></td>")
            html.append('</tr></table>');parts.append(''.join(html))
        self.chat.setHtml("<style>body{font-family:'Segoe UI';font-size:10pt;color:#f2f3f5;} h1,h2,h3{color:#ffffff;} p,li{line-height:1.35;} pre{background:#1e1f22;color:#e8eaed;padding:10px;border-radius:6px;white-space:pre-wrap;} code{background:#1e1f22;padding:2px 4px;border-radius:4px;} table{border-collapse:collapse;} th,td{border:1px solid #4a4d52;padding:6px;} blockquote{border-left:3px solid #5865f2;padding-left:10px;color:#c9ccd1;} hr{border:0;border-top:1px solid #4a4d52;}</style><div>"+''.join(parts)+"</div>")
    def _settings(self):
        d=Settings(self.cfg,self)
        if d.exec()==QDialog.Accepted:self.cfg=load()
    def _attach(self):
        p,_=QFileDialog.getOpenFileName(self,'Attach image','','Images (*.png *.jpg *.jpeg *.gif *.webp *.bmp *.tif *.tiff)')
        if p:
            aid=f'userimg{len(self.attachments)+1}';self.attachments[aid]=save_attachment(p);self.conversation['attachments']=dict(self.attachments);self.stage.setText(f'{len(self.attachments)} image(s) attached')
    def _effective_cfg(self):
        effective = copy.deepcopy(self.cfg)
        thinking = self.conversation.get('thinking_override')
        research = self.conversation.get('research_override')
        if thinking:
            effective['thinking'] = thinking
        if research:
            effective['research_mode'] = research
        return effective

    def _send(self):
        if self.busy:return
        text=self.input.toPlainText().strip()
        if not text:return
        self._active_prompt=text
        self._active_message_index=len(self.conversation['messages'])
        self.conversation['messages'].append({'role':'user','content':text,'attachments':list(self.attachments.keys())});self.conversation['attachments']=dict(self.attachments);self._render();self.input.clear();self.busy=True;self.sendbtn.setEnabled(False);self.cancelbtn.setEnabled(True);self._cancel_event=threading.Event();TELEMETRY.start('GPT-OSS');TELEMETRY.update('Preparing request',8);self.worker=Worker(self._effective_cfg(),copy.deepcopy(self.conversation['messages']),None,self.workspace_mem,self.attachments,self._cancel_event,self.conversation.get('id',''));self.worker.done.connect(self._done);self.worker.failed.connect(self._fail);self.worker.cancelled.connect(self._cancelled);self.worker.finished.connect(self._worker_finished);self.worker.start()
    def _worker_finished(self):
        if self.worker is not None and self.worker.isFinished():
            self.worker.deleteLater()
            self.worker=None
    def _cancel(self):
        if not self.busy or self.worker is None:return
        self.cancelbtn.setEnabled(False);self.sendbtn.setEnabled(False);self.input.setPlainText(self._active_prompt);TELEMETRY.update('Cancelling…',TELEMETRY.snapshot()['percent'],'warning','User requested cancellation',warning=True);workflow('cancel','requested',detail='user cancellation')
        self.worker.cancel()
        # The primary local server is stopped only for an explicit user cancellation so any
        # in-flight llama.cpp generation is actually aborted. Normal requests keep it persistent.
        MODELS.stop_all()
    def _cancelled(self):
        if self._active_message_index is not None and 0 <= self._active_message_index < len(self.conversation['messages']):
            msg=self.conversation['messages'][self._active_message_index]
            if msg.get('role')=='user' and msg.get('content')==self._active_prompt:
                self.conversation['messages'].pop(self._active_message_index)
        self.busy=False;self.sendbtn.setEnabled(True);self.cancelbtn.setEnabled(False);TELEMETRY.update('Cancelled',TELEMETRY.snapshot()['percent'],'warning','User cancelled request',warning=True);TELEMETRY.finish(False);workflow('cancel','completed',detail='user cancellation');self._render()
        self._active_message_index=None;self._active_prompt='';self._cancel_event=None
    def _done(self,pair):
        self.busy=False;self.sendbtn.setEnabled(True);self.cancelbtn.setEnabled(False)
        r,e=pair; msg=getattr(r.choices[0].message,'content',None) or ''
        request_id=getattr(r,'_meteorology_request_id',None)
        workflow('model_delivery','received','normal',detail=f'request_id={request_id or "unknown"} text_chars={len(msg)}',request_id=request_id,text_length=len(msg))
        if not isinstance(msg,str) or not msg.strip():
            workflow('model_delivery','empty','error',detail=f'GPT-OSS produced an empty user-facing response request_id={request_id}',request_id=request_id)
            self._fail('GPT-OSS finished processing but returned an empty final response. See logs/model_traces for the raw response diagnostics.')
            return
        self.conversation['messages'].append({'role':'assistant','content':msg})
        self.conversation['evidence']=e[-40:];save_conv(self.conversation,self.current_ws);TELEMETRY.update('Complete',100);TELEMETRY.finish(True);self._render();self._load_conversations();
        workflow('model_delivery','rendered','normal',detail=f'request_id={request_id or "unknown"} text_chars={len(msg)}',request_id=request_id,text_length=len(msg))
        self._active_message_index=None;self._active_prompt='';self._cancel_event=None
    def _fail(self,e):
        if e=='__METEOROLOGY_AI_CANCELLED__' or (self._cancel_event and self._cancel_event.is_set()):return self._cancelled()
        self.busy=False;self.sendbtn.setEnabled(True);self.cancelbtn.setEnabled(False);TELEMETRY.update('Request failed',TELEMETRY.snapshot()['percent'],'error',e,error=True);TELEMETRY.finish(False);workflow('request','failed','error',e);QMessageBox.critical(self,'Local AI request failed',e);self._active_message_index=None;self._active_prompt='';self._cancel_event=None
    def closeEvent(self,e):
        try:
            if self.busy and self.worker is not None:
                self.worker.cancel(); MODELS.stop_all(); self.worker.wait(5000)
            TELEMETRY.unsubscribe(self.telemetry_signal.emit)
            if self.server_starter is not None and self.server_starter.isRunning():
                self.server_starter.requestInterruption()
                MODELS.stop_all()
                self.server_starter.wait(8000)
            else:
                MODELS.stop_all()
            PERF.stop();TELEMETRY.finish(True)
            if self.live is not None:self.live.hide()
            if self.diag is not None:self.diag.hide()
        except Exception:pass
        e.accept()
