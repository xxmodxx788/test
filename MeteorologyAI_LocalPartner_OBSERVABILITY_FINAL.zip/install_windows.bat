@echo off
cd /d "%~dp0"
py -3.12 -m pip install -r requirements.txt
if errorlevel 1 (echo Dependency installation failed.&pause&exit /b 1)
py -3.12 -m pip install pyinstaller
if errorlevel 1 (echo PyInstaller installation failed.&pause&exit /b 1)
echo Full installation/verification complete.
pause
