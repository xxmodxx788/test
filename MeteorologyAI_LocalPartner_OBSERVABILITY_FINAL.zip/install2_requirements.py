from importlib.metadata import version
from packaging.requirements import Requirement
from pathlib import Path
import sys
req=Path(__file__).with_name('requirements.txt')
missing=[]
for line in req.read_text(encoding='utf-8').splitlines():
 line=line.strip()
 if not line or line.startswith('#'):continue
 r=Requirement(line)
 try:
  v=version(r.name)
  if r.specifier and v not in r.specifier: missing.append(line)
 except Exception: missing.append(line)
Path(req.parent/'.install2_missing.txt').write_text('\n'.join(missing),encoding='utf-8')
print(len(missing))
for x in missing:print(x)

sys.exit(1 if missing else 0)
