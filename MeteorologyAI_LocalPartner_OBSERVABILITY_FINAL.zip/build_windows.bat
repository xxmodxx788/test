@echo off
cd /d "%~dp0"
py -3.12 -m PyInstaller --clean --noconfirm --name MeteorologyAI --onedir app.py
