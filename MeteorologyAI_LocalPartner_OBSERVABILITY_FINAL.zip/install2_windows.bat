@echo off
cd /d "%~dp0"
echo Checking only for missing or incompatible requirements...
py -3.12 -c "import packaging" >nul 2>&1
if errorlevel 1 (
  echo Installing bootstrap dependency: packaging
  py -3.12 -m pip install "packaging>=24"
  if errorlevel 1 (echo Failed to install packaging.&pause&exit /b 1)
)
py -3.12 install2_requirements.py
set COUNT=%ERRORLEVEL%
if not exist .install2_missing.txt set COUNT=0
if "%COUNT%"=="0" (
  echo All required packages are already installed with compatible versions.
) else (
  for /f "usebackq delims=" %%A in (".install2_missing.txt") do py -3.12 -m pip install "%%A"
  if errorlevel 1 (echo Required package installation failed.&pause&exit /b 1)
  echo Re-checking installed requirements...
  py -3.12 install2_requirements.py
  if errorlevel 1 (echo Requirement verification failed after installation.&pause&exit /b 1)
)
del .install2_missing.txt 2>nul
exit /b 0
